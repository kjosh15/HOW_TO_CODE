# AI-Assisted Development Workflow Framework

**Version**: 1.0.0
**Author**: Derived from NTWRKR project
**License**: MIT

A comprehensive, portable framework for AI-assisted software development using specialized agents, structured task management, and documentation-driven workflows.

---

## Table of Contents

- [Overview](#overview)
- [Philosophy](#philosophy)
- [Components](#components)
- [Installation](#installation)
- [Quick Start](#quick-start)
- [Workflow Guide](#workflow-guide)
- [Agent Reference](#agent-reference)
- [Best Practices](#best-practices)
- [Export & Portability](#export--portability)
- [Troubleshooting](#troubleshooting)

---

## Overview

This framework transforms your development process by:

✅ **Structured Thinking** - Systematic approach from idea to implementation
✅ **Knowledge Preservation** - Nothing gets lost between sessions
✅ **AI-Assisted** - Specialized agents guide each phase
✅ **Documentation-Driven** - Every decision and pattern documented
✅ **Git-Native** - Everything lives in your repository
✅ **Portable** - Works with any tech stack, any project size

### The Core Workflow

```
💡 Initial Idea
    ↓
📚 Context Gathering → Document what exists
    ↓
📝 Specification → Define what to build (with user approval)
    ↓
🗺️ Implementation Planning → Break down how to build
    ↓
📋 Task Creation → Create trackable work items
    ↓
⚙️ Implementation → Build with progress tracking
    ↓
✅ Completion → Mark done, update docs
    ↓
📖 Knowledge Capture → Document learnings for future
```

---

## Philosophy

### Core Principles

1. **Documentation is Not Optional**
   - If it's not documented, it didn't happen
   - Future you will thank present you
   - Anyone should be able to pick up where you left off

2. **Search Before Creating**
   - Always search existing docs/tasks first
   - Avoid duplicate work
   - Build on what exists

3. **User Approval Required**
   - Specifications must be approved before implementation
   - Prevents building the wrong thing
   - Keeps human in control

4. **Incremental & Iterative**
   - Small, focused tasks
   - Frequent commits
   - Regular reviews and updates

5. **AI as Collaborator, Not Replacement**
   - Agents guide and suggest
   - Human makes final decisions
   - Workflow keeps context across sessions

---

## Components

### 1. Backlog.md Task Management

**What**: Markdown-native task management with MCP integration
**Why**: Git-based, AI-accessible, 100% portable
**Source**: https://github.com/MrLesk/Backlog.md

Features:
- Tasks stored as `.md` files in your repo
- Terminal kanban board (`backlog board`)
- Web UI (`backlog browser`)
- Full-text search
- MCP integration for AI agents

### 2. Specialized AI Agents

Five agents guide your workflow:

| Agent | Purpose | Input | Output |
|-------|---------|-------|--------|
| **context-gatherer** | Understand codebase | Codebase + web research | CONTEXT.md, context.md |
| **spec-writer** | Define requirements | Context + user input | SPEC-*.md (approved) |
| **implementation-planner** | Plan implementation | Spec + context | PLAN-*.md |
| **backlog-manager** | Manage tasks | Plans + status | Tasks, reports |
| **context-maintainer** | Capture learnings | Completed work | Updated docs, ADRs |

### 3. Documentation Structure

```
your-project/
├── backlog/
│   ├── config.yml              # Backlog configuration
│   ├── tasks/                  # Task markdown files
│   │   └── task-001.md
│   └── work/                   # Task work folders
│       └── task-001/
│           ├── context.md      # Task context
│           ├── spec.md         # Task spec
│           ├── implementation.md
│           └── decisions.md
├── WORKFLOW.md                 # Agent workflow guide
├── AGENTS.md                   # Agent definitions
├── CLAUDE.md                   # AI assistant instructions
├── CONTEXT.md                  # Project context (living doc)
├── CHANGELOG.md                # Change log
├── PROJECT-SPEC.md             # Functional specification
├── BEST-PRACTICES.md           # Best practices guide
└── .github/                    # GitHub templates (optional)
```

### 4. Setup Scripts

- **setup-workflow-framework.sh** - Main setup orchestrator
- **onboard-project.sh** - Interactive project questionnaire
- **github-init.sh** - GitHub repository setup

---

## Installation

### Prerequisites

**Required**:
- Git
- One of: npm, bun, or Homebrew

**Recommended**:
- GitHub CLI (`gh`) - for GitHub integration
- Claude Code or compatible AI tool with MCP support

### Installation Steps

#### Option 1: Fresh Project Setup

```bash
# 1. Download the framework
git clone https://github.com/YOUR-REPO/workflow-framework
cd workflow-framework

# 2. Copy framework to your project directory
cp -r framework-files/* /path/to/your/project/

# 3. Navigate to your project
cd /path/to/your/project

# 4. Run setup
chmod +x setup-workflow-framework.sh
./setup-workflow-framework.sh "Your Project Name"
```

#### Option 2: Existing Project Setup

```bash
# 1. Navigate to your existing project
cd your-existing-project

# 2. Copy framework files
cp /path/to/workflow-framework/* .

# 3. Run setup
chmod +x setup-workflow-framework.sh
./setup-workflow-framework.sh
```

#### Option 3: Manual Setup

```bash
# 1. Install backlog.md
npm install -g backlog.md
# or: brew install backlog-md
# or: bun add -g backlog.md

# 2. Initialize backlog
backlog init "Your Project"

# 3. Copy workflow documentation files
cp WORKFLOW.md AGENTS.md CLAUDE.md BACKLOG.md your-project/

# 4. Customize for your project
# Edit CLAUDE.md with project-specific details
```

---

## Quick Start

### Day 1: Setup (30 minutes)

```bash
# 1. Run setup script
./setup-workflow-framework.sh "My Project"

# 2. Run onboarding questionnaire
./onboard-project.sh

# 3. Review generated files
cat PROJECT-SPEC.md
cat GETTING-STARTED.md

# 4. View your task board
backlog board
```

### Day 2: Start Building (1-2 hours)

```bash
# In Claude Code or compatible AI tool:

# 1. Gather context (if code exists)
/agents context-gatherer

# 2. Create your first spec
/agents spec-writer "System Architecture"

# 3. Review and approve the spec

# 4. Create implementation plan
/agents implementation-planner "SPEC-system-architecture.md"

# 5. Create tasks
/agents backlog-manager "Create tasks from PLAN-system-architecture.md"

# 6. View tasks
backlog board

# 7. Start working on first task!
```

### Daily Workflow

```bash
# Morning: Check what to work on
/agents backlog-manager "Daily standup"

# Work on tasks...
# - Update implementation.md as you go
# - Check off acceptance criteria
# - Document decisions in decisions.md
# - Commit frequently

# Evening: Review progress
/agents backlog-manager "Review today's progress"

# After completing tasks
/agents context-maintainer
```

---

## Workflow Guide

### Phase 1: Project Onboarding

**Goal**: Define what you're building

**Steps**:
1. Run `./onboard-project.sh`
2. Answer comprehensive questionnaire
3. Review generated `PROJECT-SPEC.md`
4. Refine as needed

**Outputs**:
- PROJECT-SPEC.md
- CONTEXT.md
- GETTING-STARTED.md
- Initial backlog tasks

### Phase 2: Architecture & Planning

**Goal**: Design how to build it

**Agent Flow**:
```bash
/agents context-gatherer  # Understand what exists
/agents spec-writer "System Architecture"  # Define architecture
/agents implementation-planner "SPEC-architecture.md"  # Plan implementation
/agents backlog-manager "Create tasks"  # Create work items
```

**Outputs**:
- Architecture specification
- Implementation plan
- Backlog tasks with ACs
- Dependency graph

### Phase 3: Implementation

**Goal**: Build the thing

**Workflow**:
```bash
# 1. Pick highest priority task
backlog task list --status "To Do"

# 2. Start task
backlog task edit task-001 --status "In Progress"

# 3. Read task context
cat backlog/work/task-001/spec.md

# 4. Implement following the plan
# - Update implementation.md with progress
# - Check off ACs as you complete them
# - Document decisions

# 5. Test

# 6. Mark complete
backlog task edit task-001 --status "Done"

# 7. Update docs
# - Add to CHANGELOG.md
# - Update CONTEXT.md if needed
```

### Phase 4: Knowledge Capture

**Goal**: Learn from what you built

**Agent Flow**:
```bash
/agents context-maintainer
```

**Outputs**:
- Updated CONTEXT.md
- LEARNING-LOG.md entries
- Architecture Decision Records (ADRs)
- Refactoring task suggestions

---

## Agent Reference

### context-gatherer

**Purpose**: Explore and understand the codebase

**When to Use**:
- First time in a project
- Before major refactors
- When context is unclear

**Capabilities**:
- File system exploration
- Code pattern analysis
- Web research (best practices, docs)
- Dependency analysis

**Example**:
```bash
/agents context-gatherer
```

**Outputs**:
- CONTEXT.md (or updates it)
- HANDOFF-context.md
- Recommendations for next steps

### spec-writer

**Purpose**: Define requirements and get user approval

**When to Use**:
- Starting new features
- Clarifying unclear requirements
- Architectural decisions

**Capabilities**:
- Read context
- Ask clarifying questions
- Get user approval
- Create specifications

**Example**:
```bash
/agents spec-writer "User Authentication System"
```

**Outputs**:
- SPEC-[name].md (after user approval)
- HANDOFF-spec-[name].md
- Suggestion for next agent

**Important**: Will ask questions and require approval before finalizing.

### implementation-planner

**Purpose**: Create detailed implementation plan

**When to Use**:
- After spec approval
- For complex features
- When breaking down epics

**Capabilities**:
- Read specs and context
- Create step-by-step plans
- Identify risks and dependencies
- Estimate effort

**Example**:
```bash
/agents implementation-planner "SPEC-user-authentication.md"
```

**Outputs**:
- PLAN-[name].md
- Ready-to-run backlog commands
- Dependency graph

### backlog-manager

**Purpose**: Manage tasks and track progress

**When to Use**:
- Creating tasks from plans
- Daily standups
- Reviewing progress
- Checking project health

**Capabilities**:
- Auto-detects project state
- Creates/updates tasks
- Generates reports
- Suggests next work

**Examples**:
```bash
/agents backlog-manager "Daily standup"
/agents backlog-manager "Create tasks from PLAN-authentication.md"
/agents backlog-manager "Weekly review"
```

**Outputs**:
- Task files in backlog/tasks/
- Status reports
- Next action suggestions

### context-maintainer

**Purpose**: Capture learnings and update documentation

**When to Use**:
- After completing tasks
- After major milestones
- Weekly/monthly reviews

**Capabilities**:
- Auto-discover completed work
- Extract patterns
- Update CONTEXT.md
- Create ADRs
- Suggest refactoring

**Example**:
```bash
/agents context-maintainer
```

**Outputs**:
- Updated CONTEXT.md
- CHANGELOG.md entries
- LEARNING-LOG.md
- ADRs (docs/architecture/decisions/)
- Refactoring task suggestions

---

## Best Practices

See BEST-PRACTICES.md for comprehensive guide.

### Quick Tips

**✅ DO**:
- Run context-gatherer first time in a project
- Always get spec approval before implementing
- Update implementation.md frequently
- Document decisions immediately
- Commit after tests pass
- Run context-maintainer after completing work

**❌ DON'T**:
- Skip spec-writer phase
- Start coding without a plan
- Forget to update CHANGELOG.md
- Mark tasks complete without checking all ACs
- Let CONTEXT.md get stale

### Task Documentation

Every task should have:
- Clear description
- Acceptance criteria
- Task work folder (backlog/work/task-XXX/)
- Progress notes in implementation.md
- Decisions documented in decisions.md

### Commit Guidelines

- Commit frequently (after tests pass)
- Reference task IDs: "feat: Add login endpoint [task-042]"
- Update CHANGELOG.md before marking tasks done
- Don't commit secrets or sensitive data

---

## Export & Portability

### Exporting to New Projects

#### Quick Export

```bash
# From NTWRKR or any project with framework

# 1. Copy framework files
cp setup-workflow-framework.sh /target/project/
cp onboard-project.sh /target/project/
cp github-init.sh /target/project/
cp -r templates /target/project/
cp FRAMEWORK-README.md /target/project/
cp BEST-PRACTICES.md /target/project/

# 2. Run setup in target project
cd /target/project
./setup-workflow-framework.sh "New Project Name"
```

#### Creating a Framework Package

Create a reusable package:

```bash
# 1. Create framework directory
mkdir workflow-framework
cd workflow-framework

# 2. Copy core files
cp setup-workflow-framework.sh .
cp onboard-project.sh .
cp github-init.sh .
cp -r templates .
cp FRAMEWORK-README.md README.md
cp BEST-PRACTICES.md .

# 3. Create install script
cat > install.sh << 'EOF'
#!/bin/bash
TARGET_DIR="${1:-.}"
cp -r * "$TARGET_DIR/"
cd "$TARGET_DIR"
chmod +x *.sh
./setup-workflow-framework.sh
EOF

chmod +x install.sh

# 4. Package it
tar -czf workflow-framework-v1.0.tar.gz *

# 5. Share or version control
git init
git add .
git commit -m "Initial workflow framework package"
```

#### Using the Package

```bash
# Download and extract
tar -xzf workflow-framework-v1.0.tar.gz
./install.sh /path/to/my/project
```

### Framework Components Checklist

When exporting, ensure you include:

**Essential**:
- [ ] setup-workflow-framework.sh
- [ ] onboard-project.sh
- [ ] github-init.sh
- [ ] templates/WORKFLOW.md
- [ ] templates/AGENTS.md
- [ ] templates/CLAUDE.md
- [ ] templates/BACKLOG.md
- [ ] FRAMEWORK-README.md
- [ ] BEST-PRACTICES.md

**Optional**:
- [ ] Example task structures
- [ ] GitHub Actions templates
- [ ] Docker configurations
- [ ] Language-specific templates

---

## Troubleshooting

### Common Issues

#### "backlog command not found"

```bash
# Install backlog.md
npm install -g backlog.md
# or
brew install backlog-md
```

#### "gh command not found"

```bash
# Install GitHub CLI
brew install gh
# or visit: https://cli.github.com/
```

#### Agents not responding in Claude Code

- Ensure MCP is configured
- Check `backlog://workflow/overview` resource is accessible
- Restart Claude Code

#### Tasks not showing in backlog board

```bash
# Check backlog configuration
cat backlog/config.yml

# Verify tasks directory
ls backlog/tasks/

# Try recreating board
backlog board --refresh
```

#### Workflow files not found during setup

- Ensure you're running setup from correct directory
- Check templates directory exists
- Verify file permissions (`chmod +x *.sh`)

### Getting Help

1. **Read the docs**:
   - WORKFLOW.md - Workflow details
   - AGENTS.md - Agent capabilities
   - BEST-PRACTICES.md - Development guidelines

2. **Check backlog.md docs**:
   - https://github.com/MrLesk/Backlog.md

3. **Review examples**:
   - Look at backlog/work/task-*/  structures in NTWRKR

---

## Version History

- **1.0.0** (2025) - Initial release
  - Complete workflow system
  - Five specialized agents
  - Portable setup scripts
  - Comprehensive documentation

---

## License

MIT License - Feel free to use, modify, and distribute.

---

## Credits

This framework was derived from the NTWRKR project and synthesizes best practices from:

- Task management: Backlog.md (MrLesk)
- AI collaboration: Claude Code (Anthropic)
- Documentation practices: ADRs, Keep a Changelog
- Agile methodologies: User stories, acceptance criteria
- Knowledge management: Context preservation, decision logs

---

## Next Steps

1. **Install the framework**: Run `./setup-workflow-framework.sh`
2. **Complete onboarding**: Run `./onboard-project.sh`
3. **Read the workflow**: Review WORKFLOW.md
4. **Start building**: Follow the agent workflow
5. **Share feedback**: Improve this framework for everyone

**Happy building!** 🚀
