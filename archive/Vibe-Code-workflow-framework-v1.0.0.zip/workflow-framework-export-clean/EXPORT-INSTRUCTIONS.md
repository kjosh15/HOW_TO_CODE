# Framework Export Instructions

**Framework Version**: 1.0.0
**Date**: 2025

This document explains how to export and use the AI-Assisted Development Workflow Framework in your other projects.

---

## What You Have

A complete, portable framework that includes:

✅ **Setup Scripts**:
- `setup-workflow-framework.sh` - Main setup orchestrator
- `onboard-project.sh` - Interactive project questionnaire
- `github-init.sh` - GitHub repository setup
- `export-framework.sh` - Package for distribution

✅ **Documentation**:
- `FRAMEWORK-README.md` - Complete framework overview
- `WORKFLOW.md` - Agent workflow system
- `AGENTS.md` - Agent definitions
- `BEST-PRACTICES.md` - Development best practices
- `USAGE-GUIDE.md` - Practical daily usage
- Template files in `templates/`

✅ **Integration**:
- Backlog.md task management
- Claude Code / MCP support
- GitHub integration
- Git-native storage

---

## Quick Export (5 minutes)

### Option 1: Export to Single Project

```bash
# 1. Navigate to target project
cd /path/to/your/other/project

# 2. Copy framework files from NTWRKR
cp /path/to/NTWRKR/setup-workflow-framework.sh .
cp /path/to/NTWRKR/onboard-project.sh .
cp /path/to/NTWRKR/github-init.sh .
cp /path/to/NTWRKR/FRAMEWORK-README.md .
cp /path/to/NTWRKR/BEST-PRACTICES.md .
cp /path/to/NTWRKR/USAGE-GUIDE.md .
cp -r /path/to/NTWRKR/templates .

# 3. Make scripts executable
chmod +x *.sh

# 4. Run setup
./setup-workflow-framework.sh "Your Project Name"
```

### Option 2: Create Reusable Bundle

```bash
# 1. Navigate to NTWRKR directory
cd /path/to/NTWRKR

# 2. Run export script
./export-framework.sh ~/Desktop/workflow-framework-bundle

# This creates:
# - ~/Desktop/workflow-framework-bundle/ (directory)
# - workflow-framework-v1.0.tar.gz (portable archive)

# 3. Use the bundle in any project
cd /path/to/any/project
tar -xzf ~/Desktop/workflow-framework-v1.0.tar.gz
./workflow-framework-bundle/install.sh
```

---

## Detailed Export Process

### Step 1: Create Framework Package

```bash
cd /path/to/NTWRKR

# Run export script (creates bundle + tarball)
./export-framework.sh /path/to/output

# Output:
# - /path/to/output/workflow-framework-bundle/
# - workflow-framework-v1.0.tar.gz
```

**What gets packaged:**
```
workflow-framework-bundle/
├── setup-workflow-framework.sh
├── onboard-project.sh
├── github-init.sh
├── export-framework.sh
├── install.sh                    # New: Quick installer
├── FRAMEWORK-README.md
├── BEST-PRACTICES.md
├── USAGE-GUIDE.md
├── README.md                     # New: Bundle-specific
├── VERSION
├── templates/
│   ├── WORKFLOW.md
│   ├── AGENTS.md
│   ├── CLAUDE.md
│   └── BACKLOG.md
└── examples/
    └── task-example/             # Example task structure
        ├── task-001-example.md
        └── work/
            └── task-001/
                ├── context.md
                ├── spec.md
                ├── implementation.md
                └── decisions.md
```

### Step 2: Distribute the Framework

Choose your distribution method:

#### A. Share the Directory

```bash
# Compress for sharing
cd /path/to/output
zip -r workflow-framework-v1.0.zip workflow-framework-bundle/

# Send via email, Slack, or internal file share
```

#### B. Share the Tarball

```bash
# Already created by export script
# Share: workflow-framework-v1.0.tar.gz
```

#### C. Git Repository

```bash
cd workflow-framework-bundle
git init
git add .
git commit -m "Initial framework release v1.0.0"

# Push to GitHub/GitLab/etc
git remote add origin https://github.com/your-org/workflow-framework.git
git push -u origin main

# Tag the release
git tag -a v1.0.0 -m "Release version 1.0.0"
git push --tags
```

#### D. Internal Package Registry

```bash
# Create npm package (if your org uses npm)
cd workflow-framework-bundle
cat > package.json << EOF
{
  "name": "@your-org/workflow-framework",
  "version": "1.0.0",
  "description": "AI-Assisted Development Workflow Framework",
  "bin": {
    "workflow-install": "./install.sh"
  },
  "files": [
    "*.sh",
    "*.md",
    "templates",
    "examples"
  ]
}
EOF

# Publish to internal registry
npm publish
```

### Step 3: Install in New Projects

#### Installation Method 1: Using install.sh

```bash
cd your-new-project

# Extract bundle
tar -xzf workflow-framework-v1.0.tar.gz

# Run installer
./workflow-framework-bundle/install.sh .

# Run setup
./setup-workflow-framework.sh "Your Project Name"
```

#### Installation Method 2: Manual

```bash
cd your-new-project

# Copy files
cp -r /path/to/workflow-framework-bundle/* .

# Make executable
chmod +x *.sh

# Run setup
./setup-workflow-framework.sh "Your Project Name"
```

#### Installation Method 3: From Git

```bash
cd your-new-project

# Clone framework
git clone https://github.com/your-org/workflow-framework.git .framework

# Install
.framework/install.sh .

# Cleanup (optional)
rm -rf .framework
```

---

## Customization for Your Organization

### Creating an Org-Specific Version

```bash
# 1. Export the base framework
./export-framework.sh ~/org-framework

# 2. Customize for your org
cd ~/org-framework/workflow-framework-bundle

# 3. Update templates/CLAUDE.md with org standards
cat >> templates/CLAUDE.md << EOF

## Organization-Specific Conventions

### Code Style
- ESLint config: @your-org/eslint-config
- Prettier config: @your-org/prettier-config

### Testing Requirements
- Minimum coverage: 80%
- E2E tests required for user-facing features

### Deployment
- All deployments via GitHub Actions
- Staging required before production

### Security
- All dependencies must pass Snyk scan
- SAST required for PRs
EOF

# 4. Add org-specific templates
mkdir templates/org-templates
# Add your internal doc templates

# 5. Update BEST-PRACTICES.md with org standards

# 6. Repackage
cd ..
tar -czf workflow-framework-org-v1.0.tar.gz workflow-framework-bundle/
```

---

## Using the Framework

### First Time Setup (new project)

```bash
# 1. Extract and install
cd your-project
tar -xzf workflow-framework-v1.0.tar.gz
./workflow-framework-bundle/install.sh

# 2. Run setup (installs backlog.md, creates structure)
./setup-workflow-framework.sh "My New Project"

# 3. Run onboarding (generates spec and initial tasks)
./onboard-project.sh

# 4. Review outputs
cat PROJECT-SPEC.md
cat GETTING-STARTED.md
backlog board

# 5. Start building!
```

### Existing Project Setup

```bash
# 1. Install framework
cd your-existing-project
tar -xzf workflow-framework-v1.0.tar.gz
./workflow-framework-bundle/install.sh

# 2. Run setup (may skip some steps if already setup)
./setup-workflow-framework.sh

# 3. Run context-gatherer to understand existing code
# (In Claude Code or compatible AI tool)
/agents context-gatherer

# 4. Optionally run onboarding to document current state
./onboard-project.sh

# 5. Start using the workflow
backlog board
/agents backlog-manager "Create initial tasks from CONTEXT.md"
```

---

## Maintenance and Updates

### Updating the Framework

When you improve the framework in one project:

```bash
# 1. Make improvements in NTWRKR (or any project)
# e.g., improve onboard-project.sh

# 2. Export updated framework
cd NTWRKR
./export-framework.sh ~/workflow-framework-v1.1

# 3. Update version
echo "1.1.0" > ~/workflow-framework-v1.1/workflow-framework-bundle/VERSION

# 4. Distribute updated version
tar -czf workflow-framework-v1.1.tar.gz \
  -C ~/workflow-framework-v1.1 workflow-framework-bundle/
```

### Upgrading Existing Projects

```bash
# In project using old version:
cd your-project

# 1. Backup current config
cp backlog/config.yml backlog/config.yml.bak
cp CLAUDE.md CLAUDE.md.bak

# 2. Extract new version
tar -xzf workflow-framework-v1.1.tar.gz

# 3. Manually merge improvements
# - Copy updated scripts
cp workflow-framework-bundle/setup-workflow-framework.sh .
cp workflow-framework-bundle/onboard-project.sh .

# - Review template changes
diff CLAUDE.md workflow-framework-bundle/templates/CLAUDE.md

# 4. Restore your customizations
# Merge config.yml.bak changes back
```

---

## Integration with CI/CD

### GitHub Actions Example

```yaml
# .github/workflows/framework-check.yml
name: Framework Compliance

on: [push, pull_request]

jobs:
  check:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Check documentation
        run: |
          # Ensure key docs exist
          test -f CONTEXT.md || echo "⚠️ Missing CONTEXT.md"
          test -f CHANGELOG.md || echo "⚠️ Missing CHANGELOG.md"
          test -f PROJECT-SPEC.md || echo "⚠️ Missing PROJECT-SPEC.md"

      - name: Check backlog health
        run: |
          # Install backlog.md
          npm install -g backlog.md

          # Health check
          backlog task list --status "In Progress" | wc -l | \
            awk '{if ($1 > 5) print "⚠️ Too many WIP tasks: " $1}'
```

---

## Troubleshooting Export

### Issue: "Templates not found"

Ensure templates exist before exporting:

```bash
# Check templates
ls -la templates/

# If missing, copy from NTWRKR
cp WORKFLOW.md templates/
cp AGENTS.md templates/
cp CLAUDE.md templates/
cp BACKLOG.md templates/
```

### Issue: "Scripts not executable after extract"

```bash
# Fix permissions
chmod +x *.sh
chmod +x workflow-framework-bundle/*.sh
```

### Issue: "Modified framework not exporting changes"

```bash
# Ensure you're exporting from correct directory
pwd  # Should be in NTWRKR or project with updated files

# Check file timestamps
ls -lt *.sh
```

---

## Checklist for Distribution

Before sharing the framework, verify:

- [ ] All scripts are executable
- [ ] Templates directory exists and is populated
- [ ] Documentation files are included
- [ ] Example task structure is included
- [ ] VERSION file exists
- [ ] README.md explains how to install
- [ ] install.sh works in test project
- [ ] No project-specific information in templates
- [ ] No sensitive data or API keys
- [ ] License file included (if applicable)

---

## Framework Files Reference

### Essential Files (Required)

| File | Purpose | User Editable? |
|------|---------|----------------|
| setup-workflow-framework.sh | Main setup orchestrator | No |
| onboard-project.sh | Project questionnaire | No |
| github-init.sh | GitHub setup | No |
| install.sh | Quick installer | No |
| FRAMEWORK-README.md | Framework overview | No |
| BEST-PRACTICES.md | Best practices guide | Extend |
| USAGE-GUIDE.md | Daily usage guide | Extend |
| templates/WORKFLOW.md | Workflow documentation | No |
| templates/AGENTS.md | Agent definitions | No |
| templates/CLAUDE.md | AI instructions | **Yes** |
| templates/BACKLOG.md | Backlog integration | No |

### Generated Files (Created by Setup)

| File | Created By | Purpose |
|------|-----------|---------|
| PROJECT-SPEC.md | onboard-project.sh | Project specification |
| CONTEXT.md | onboard-project.sh or context-gatherer | Project context |
| GETTING-STARTED.md | onboard-project.sh | Next steps guide |
| CHANGELOG.md | setup or manual | Change log |
| backlog/config.yml | backlog init | Backlog configuration |
| backlog/tasks/*.md | backlog task create | Task files |
| backlog/work/task-*/ | Agents or manual | Task work folders |

---

## Support and Community

### Getting Help

1. **Read the docs first**:
   - FRAMEWORK-README.md - Complete overview
   - USAGE-GUIDE.md - Daily workflows
   - BEST-PRACTICES.md - Development guidelines

2. **Check examples**:
   - examples/task-example/ - Example task structure
   - NTWRKR backlog/work/task-*/ - Real task examples

3. **Community resources**:
   - Backlog.md: https://github.com/MrLesk/Backlog.md
   - Claude Code docs: https://docs.claude.com/claude-code

### Contributing Improvements

If you improve the framework:

1. Document the improvement
2. Test in a real project
3. Share back with your team/community
4. Update version number
5. Re-export and distribute

---

## Quick Commands Reference

```bash
# Export framework from NTWRKR
cd /path/to/NTWRKR
./export-framework.sh ~/Desktop/my-framework-bundle

# Install in new project
cd /path/to/new/project
tar -xzf workflow-framework-v1.0.tar.gz
./workflow-framework-bundle/install.sh

# Setup new project
./setup-workflow-framework.sh "Project Name"
./onboard-project.sh

# View results
cat PROJECT-SPEC.md
backlog board
```

---

**That's it!** You now have a complete, portable framework that you can use in any project. The framework is designed to be:

- ✅ **Self-contained** - All files included
- ✅ **Portable** - Works on any platform with Git
- ✅ **Customizable** - Adapt to your needs
- ✅ **Documented** - Comprehensive guides included
- ✅ **Proven** - Battle-tested in NTWRKR

Happy exporting! 🚀
