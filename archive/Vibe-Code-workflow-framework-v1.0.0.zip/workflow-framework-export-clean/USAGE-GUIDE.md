# Framework Usage Guide

**Version**: 1.0.0
**For**: AI-Assisted Development Workflow Framework

A practical, step-by-step guide to using the framework in your daily development work.

---

## Table of Contents

- [Getting Started](#getting-started)
- [Daily Workflows](#daily-workflows)
- [Feature Development](#feature-development)
- [Bug Fixing](#bug-fixing)
- [Refactoring](#refactoring)
- [Team Scenarios](#team-scenarios)
- [Troubleshooting](#troubleshooting)

---

## Getting Started

### Your First Day with the Framework

#### Step 1: Installation (10 minutes)

```bash
# Extract the framework bundle
cd your-project
tar -xzf workflow-framework-v1.0.tar.gz

# Run setup
./workflow-framework-bundle/install.sh .
./setup-workflow-framework.sh "Your Project Name"
```

**What happens:**
- Installs backlog.md
- Initializes Git repo (if needed)
- Creates backlog/ directory structure
- Copies workflow documentation
- Sets up GitHub (optional)

#### Step 2: Project Onboarding (15 minutes)

```bash
./onboard-project.sh
```

**You'll be asked about:**
- Project basics (name, description, goal)
- Target audience
- Technical stack
- Core features (MVP vs nice-to-have)
- Constraints (timeline, budget, team size)
- Deployment plans
- Quality requirements

**Outputs generated:**
- `PROJECT-SPEC.md` - Your project blueprint
- `CONTEXT.md` - Initial project context
- `GETTING-STARTED.md` - Your next steps
- Initial backlog tasks

#### Step 3: First Look Around (5 minutes)

```bash
# View your task board
backlog board

# Read your project spec
cat PROJECT-SPEC.md

# Check getting started guide
cat GETTING-STARTED.md

# View workflow documentation
cat WORKFLOW.md
```

---

## Daily Workflows

### Morning Routine

**Time**: 5-10 minutes
**Goal**: Know what to work on today

```bash
# 1. Update from remote (if team project)
git pull origin main

# 2. Morning standup
# In Claude Code or compatible AI tool:
/agents backlog-manager "Daily standup: what should I work on today?"
```

**Expected output:**
```
📊 Daily Standup Report

Current Sprint Status:
- 3 tasks In Progress
- 8 tasks To Do
- 12 tasks Done this week

🎯 Suggested Priorities:
1. task-042: Implement user login (HIGH priority, blocking task-045)
2. task-043: Add input validation (MEDIUM priority, ready to start)

⚠️ Attention Needed:
- task-038: In Progress for 5 days (consider breaking down?)

📌 Next Actions:
1. Continue task-042 if you were working on it
2. Or start task-043 if task-042 is blocked
```

```bash
# 3. View visual board
backlog board

# 4. Pick your task
backlog task edit task-042 --status "In Progress"
```

### Working on a Task

**Time**: 2-8 hours per task (ideal)
**Goal**: Complete task efficiently with good documentation

#### Starting the Task

```bash
# 1. Mark as in progress
backlog task edit task-042 --status "In Progress"

# 2. Read task materials
cat backlog/tasks/task-042-implement-user-login.md

# If work folder exists:
cat backlog/work/task-042/spec.md
cat backlog/work/task-042/implementation.md
cat backlog/work/task-042/context.md
```

#### During Implementation

**Every 30-60 minutes:**

1. **Save your progress**:
   ```bash
   # Update implementation.md with progress notes
   # Example entry:

   ### 2025-01-15 14:30
   - Implemented password verification with BCrypt
   - Created JWT token generation function
   - Added unit tests (passing)

   **Next**: Implement the API endpoint
   ```

2. **Make decisions visible**:
   ```bash
   # When you make a design decision, add to decisions.md:

   ### [2025-01-15] Use BCrypt over Argon2
   **Context**: Need password hashing
   **Decision**: BCrypt
   **Rationale**: More mature, team familiar with it
   **Consequences**: Can migrate to Argon2 later if needed
   ```

3. **Commit incrementally**:
   ```bash
   # After a logical unit of work is done and tested:
   git add .
   git commit -m "feat: Add password verification function [task-042]

   - Implement verify_password with BCrypt
   - Add unit tests with edge cases
   - Configure BCrypt cost factor in settings

   Progress: AC1 complete, AC2-4 in progress"
   ```

#### Completing the Task

**Before marking done**, ensure:

```bash
# Checklist:
# [ ] All acceptance criteria checked
# [ ] Tests passing
# [ ] No linting errors
# [ ] Documentation updated

# 1. Run tests
make test  # or your test command

# 2. Run linting
make check  # or your lint command

# 3. Update CHANGELOG.md
# Add entry under [Unreleased] section:
### Added
- [task-042](backlog/work/task-042/) User login endpoint with JWT authentication

# 4. Final commit
git add .
git commit -m "feat: Complete user login endpoint [task-042]

All acceptance criteria met:
✓ AC1: Endpoint accepts email/password
✓ AC2: Returns JWT on success
✓ AC3: Returns 401 on invalid credentials
✓ AC4: Input validation works
✓ AC5: Tests pass with 85% coverage

Closes task-042"

# 5. Mark task done
backlog task edit task-042 --status "Done" --check-ac 1 --check-ac 2 --check-ac 3 --check-ac 4 --check-ac 5

# 6. Push (if team project)
git push origin main  # or your branch
```

### End of Day

**Time**: 5-10 minutes
**Goal**: Clean state for tomorrow

```bash
# 1. Update any in-progress tasks
# Add session notes to implementation.md files

# 2. Commit work in progress
git add .
git commit -m "wip: User login endpoint [task-042]

Session progress:
- Completed password verification
- Started JWT token generation
- Tests passing so far

Next session: Complete token generation, add endpoint"

# 3. Review progress
/agents backlog-manager "Review today's progress"

# 4. (Optional) Plan tomorrow
# Add "Next steps" to implementation.md
```

---

## Feature Development

### Scenario: Building a New Feature

**Example**: "Add user authentication system"

### Phase 1: Context & Spec (1-2 hours)

```bash
# Step 1: Gather context (if needed)
/agents context-gatherer
```

**Agent will**:
- Explore codebase
- Search for existing auth patterns
- Research best practices online
- Create/update CONTEXT.md

```bash
# Step 2: Write specification
/agents spec-writer "User Authentication System"
```

**Agent will**:
- Ask clarifying questions:
  - "What authentication methods? (email/password, OAuth, both?)"
  - "Need registration or just login for MVP?"
  - "Token expiration time?"
  - "Password requirements?"

- Generate spec document
- **Ask for your approval**

**You must**:
- Answer questions thoughtfully
- Review the spec
- Approve or request changes

**Output**: `SPEC-user-authentication.md`

### Phase 2: Planning (30-60 minutes)

```bash
# Step 3: Create implementation plan
/agents implementation-planner "SPEC-user-authentication.md"
```

**Agent will**:
- Break down into steps
- Identify files to create/modify
- Note dependencies
- Estimate effort
- Flag risks

**Output**: `PLAN-user-authentication.md`

```bash
# Step 4: Create tasks
/agents backlog-manager "Create tasks from PLAN-user-authentication.md"
```

**Agent will**:
- Generate task creation commands
- Set up dependencies
- Assign priorities

**Output**: Multiple tasks in `backlog/tasks/`

```bash
# Step 5: View your work
backlog board
```

### Phase 3: Implementation (days/weeks)

**Follow daily workflow** for each task:

1. Pick highest priority task (no dependencies blocking)
2. Read task materials
3. Implement incrementally
4. Document as you go
5. Test continuously
6. Commit frequently
7. Mark done when all ACs met

### Phase 4: Learning Capture (30 minutes)

**After feature is complete:**

```bash
/agents context-maintainer
```

**Agent will**:
- Review completed tasks
- Extract patterns learned
- Update CONTEXT.md
- Suggest ADRs for big decisions
- Identify refactoring opportunities

**Output**:
- Updated CONTEXT.md
- LEARNING-LOG.md entries
- Suggested refactoring tasks

---

## Bug Fixing

### Scenario: Production Bug Report

**Example**: "Login endpoint returns 500 error for some users"

### Quick Bug Fix Workflow

```bash
# 1. Create bug task immediately
backlog task create "Fix: Login returns 500 for some users" \
  --description "Error occurs when user email has uppercase letters" \
  --label bug \
  --priority high \
  --ac "Identify root cause" \
  --ac "Fix the bug" \
  --ac "Add regression test" \
  --ac "Verify no other uppercase issues"

# 2. Start work
backlog task edit task-050 --status "In Progress"

# 3. Create work folder for investigation
mkdir -p backlog/work/task-050
```

```markdown
# backlog/work/task-050/context.md

## Bug Report

**Symptom**: Login endpoint returns 500 error
**Reproduction**: Login with email containing uppercase (e.g., "User@example.com")
**Expected**: Should work regardless of case
**Actual**: 500 Internal Server Error

## Investigation Notes

### 2025-01-15 10:00
- Checked logs: KeyError on email lookup
- Database stores emails lowercase
- Login doesn't lowercase input before query
- Root cause identified: Missing .lower() on email input

## Fix Strategy

1. Add .lower() to email input normalization
2. Add validation to ensure emails always stored lowercase
3. Add test cases for case variations
4. Audit other email usages in codebase
```

```bash
# 4. Implement fix
# ... code changes ...

# 5. Test thoroughly
pytest tests/test_auth.py -v
pytest tests/test_auth.py::test_login_case_insensitive

# 6. Update CHANGELOG
```

```markdown
### Fixed
- [task-050](backlog/work/task-050/) Login endpoint now handles email case insensitively
```

```bash
# 7. Commit and deploy
git add .
git commit -m "fix: Handle email case insensitivity in login [task-050]

- Normalize email to lowercase before database query
- Add validation on user creation
- Add regression test for case variations
- Audit found 2 other instances, fixed them too

Fixes #50"

# 8. Mark done
backlog task edit task-050 --status "Done" --check-ac all
```

---

## Refactoring

### Scenario: Technical Debt or Improvement

**Example**: "Extract authentication logic into service layer"

### Refactoring Workflow

```bash
# 1. Check if agent suggests it
/agents context-maintainer
# May suggest: "Authentication logic scattered across files, recommend extracting to service"

# 2. Create refactoring task
backlog task create "Refactor: Extract auth logic to service layer" \
  --description "Consolidate authentication logic into AuthService class" \
  --label refactor \
  --priority medium \
  --ac "Create AuthService class" \
  --ac "Move password verification to service" \
  --ac "Move token generation to service" \
  --ac "Update all callers to use service" \
  --ac "All tests still pass" \
  --ac "No behavior changes"

# 3. Start work
backlog task edit task-051 --status "In Progress"

# 4. Create spec for clarity
```

```markdown
# backlog/work/task-051/spec.md

## Objective

Extract scattered authentication logic into a cohesive AuthService.

## Current State

- Password verification in src/api/auth.py
- Token generation in src/api/auth.py
- Some auth utilities in src/utils/security.py
- No clear separation of concerns

## Target State

```
src/services/auth.py
  class AuthService:
    - verify_password(plain, hashed) -> bool
    - create_access_token(user_id) -> str
    - verify_token(token) -> dict
```

## Migration Strategy

1. Create service with existing logic
2. Update callers one at a time
3. Remove old implementations
4. Verify tests pass at each step

## Non-Goals

- NOT adding new features
- NOT changing authentication behavior
- NOT changing token format
```

```bash
# 5. Implement incrementally
# Test after EACH step

# 6. Commit frequently
git commit -m "refactor: Create AuthService class [task-051]"
git commit -m "refactor: Migrate password verification to AuthService [task-051]"
git commit -m "refactor: Migrate token generation to AuthService [task-051]"
git commit -m "refactor: Update all callers to use AuthService [task-051]"
git commit -m "refactor: Remove old auth utility functions [task-051]"

# 7. Verify everything still works
make test
make check

# 8. Document the decision
```

```markdown
# backlog/work/task-051/decisions.md

### [2025-01-15] Extract to Service Layer

**Context**: Authentication logic scattered across multiple modules

**Decision**: Extract to AuthService class in services layer

**Rationale**:
- Single responsibility principle
- Easier to test in isolation
- Clearer dependency injection
- Prepares for future auth features

**Consequences**:
- All auth callers now depend on AuthService
- Service must be initialized at app startup
- Pattern to follow for other business logic
```

```bash
# 9. Mark done
backlog task edit task-051 --status "Done"
```

---

## Team Scenarios

### Scenario: Small Team (2-5 people)

#### Morning Sync (10 minutes)

```bash
# Each person independently:
/agents backlog-manager "Daily standup"

# Then quick call:
# - Share what you're working on
# - Mention blockers
# - Coordinate dependencies
```

#### During Day

```bash
# Claim tasks explicitly
backlog task edit task-042 --assignee "@yourname" --status "In Progress"

# Others see it's taken
backlog board
# Shows: task-042 assigned to @yourname
```

#### Pull Request Workflow

```bash
# 1. Work on feature branch
git checkout -b feature/task-042-user-login

# 2. Implement following task workflow
# ... work, commit, document ...

# 3. Push branch
git push origin feature/task-042-user-login

# 4. Create PR
gh pr create --title "feat: User login endpoint [task-042]" \
  --body "$(cat <<EOF
## Description

Implements user login endpoint with JWT authentication.

## Related Task

See task-042 and backlog/work/task-042/ for full context.

## Changes

- Added POST /auth/login endpoint
- Implemented JWT token generation
- Added password verification with BCrypt
- Added input validation
- Added tests (85% coverage)

## Testing

\`\`\`bash
pytest tests/test_auth.py -v
\`\`\`

## Checklist

- [x] All ACs met
- [x] Tests passing
- [x] Linting clean
- [x] CHANGELOG.md updated
- [x] Documentation updated
EOF
)"

# 5. Request review
gh pr ready

# 6. After approval and merge
backlog task edit task-042 --status "Done"
```

#### Weekly Team Review

```bash
# Designate one person to run:
/agents context-maintainer

# Review output as team:
# - What patterns emerged?
# - What ADRs to create?
# - What refactoring needed?
# - Distribute suggested tasks
```

---

## Troubleshooting

### Issue: "Agent isn't responding"

**Check**:
```bash
# 1. Verify backlog.md is accessible
backlog --version

# 2. Check MCP resource
# In Claude Code, try accessing:
backlog://workflow/overview

# 3. Restart Claude Code

# 4. Verify backlog directory exists
ls -la backlog/
```

### Issue: "Task board is empty"

```bash
# Check tasks exist
ls backlog/tasks/

# If empty, create first task
backlog task create "Setup: Initialize project" \
  --description "Get project started" \
  --label setup

# Refresh board
backlog board --refresh
```

### Issue: "Can't find task work folder"

```bash
# Create manually if needed
mkdir -p backlog/work/task-042

# Or let spec-writer create it
/agents spec-writer "User Login (task-042)"
```

### Issue: "CONTEXT.md out of date"

```bash
# Quick update
/agents context-maintainer

# Or manual update
# Edit CONTEXT.md directly
# Update "Last Updated" date
```

### Issue: "Too many tasks in progress"

```bash
# List current WIP
backlog task list --status "In Progress"

# Force yourself to finish:
# Pick ONE task
# Close or defer the others
backlog task edit task-XXX --status "To Do"  # Defer
```

### Issue: "Forgot to update CHANGELOG"

```bash
# Amend last commit (if not pushed)
# 1. Edit CHANGELOG.md
# 2. Stage it
git add CHANGELOG.md

# 3. Amend
git commit --amend --no-edit

# If already pushed, make new commit:
git commit -m "docs: Update CHANGELOG for task-042"
```

---

## Quick Reference Card

### Daily Commands

```bash
# Morning
/agents backlog-manager "Daily standup"
backlog board

# Start task
backlog task edit task-XXX --status "In Progress"
cat backlog/work/task-XXX/spec.md

# During work
# Update implementation.md frequently
git commit -m "..." # After each unit of work

# End of day
/agents backlog-manager "Review progress"
```

### Weekly Commands

```bash
/agents backlog-manager "Weekly review"
/agents context-maintainer
# Review and update CONTEXT.md
```

### Feature Development

```bash
/agents context-gatherer  # If needed
/agents spec-writer "Feature Name"  # Get approval!
/agents implementation-planner "SPEC-feature.md"
/agents backlog-manager "Create tasks from PLAN-feature.md"
# ... implement tasks ...
/agents context-maintainer
```

### Before Marking Task Done

- [ ] All ACs checked
- [ ] Tests passing
- [ ] CHANGELOG.md updated
- [ ] implementation.md has completion notes
- [ ] Committed and pushed

---

**Remember**: The framework is here to help, not constrain. Adapt it to your needs, but keep the core practices: document decisions, track work, and capture learnings.

**Happy building!** 🚀
