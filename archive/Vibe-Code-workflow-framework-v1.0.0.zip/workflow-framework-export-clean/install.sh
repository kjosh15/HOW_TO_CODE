#!/usr/bin/env bash
set -euo pipefail

# Quick installer for AI-Assisted Development Workflow Framework
FRAMEWORK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET_DIR="${1:-.}"

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "AI-Assisted Development Workflow Framework v1.0.0"
echo "Quick Installer"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "Installing from: $FRAMEWORK_DIR"
echo "Installing to: $TARGET_DIR"
echo ""

# Copy all files to target if not installing in place
if [[ "$TARGET_DIR" != "." && "$TARGET_DIR" != "$FRAMEWORK_DIR" ]]; then
    echo "Copying framework files..."
    cp "$FRAMEWORK_DIR"/*.sh "$TARGET_DIR/" 2>/dev/null || true
    cp "$FRAMEWORK_DIR"/*.md "$TARGET_DIR/" 2>/dev/null || true
    cp -r "$FRAMEWORK_DIR/templates" "$TARGET_DIR/" 2>/dev/null || true
    echo "✓ Files copied"
    echo ""
fi

# Make scripts executable
cd "$TARGET_DIR"
chmod +x *.sh 2>/dev/null || true

echo "✓ Scripts are now executable"
echo ""
echo "Next steps:"
echo "  1. ./setup-workflow-framework.sh \"Your Project Name\""
echo "  2. ./onboard-project.sh"
echo "  3. backlog board"
echo ""
echo "Read FRAMEWORK-README.md for complete guide."
echo ""
