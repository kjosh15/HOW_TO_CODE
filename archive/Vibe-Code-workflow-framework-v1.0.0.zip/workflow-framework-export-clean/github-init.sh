#!/usr/bin/env bash
set -euo pipefail

################################################################################
# GitHub Repository Initialization Helper
#
# This script helps initialize and configure a GitHub repository for your
# project, including:
# - Repository creation
# - Branch protection
# - Labels setup
# - GitHub Actions workflows
# - Issue templates
#
################################################################################

VERSION="1.0.0"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m'

log_info() { echo -e "${BLUE}ℹ${NC} $1"; }
log_success() { echo -e "${GREEN}✓${NC} $1"; }
log_warning() { echo -e "${YELLOW}⚠${NC} $1"; }
log_error() { echo -e "${RED}✗${NC} $1"; }
log_header() {
    echo ""
    echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${MAGENTA}$1${NC}"
    echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
}

command_exists() {
    command -v "$1" >/dev/null 2>&1
}

prompt() {
    local prompt="$1"
    local default="$2"
    local result

    read -p "$(echo -e ${CYAN}$prompt ${NC}[${default}]: )" result
    echo "${result:-$default}"
}

prompt_yes_no() {
    local prompt="$1"
    local default="${2:-y}"
    local result

    if [[ "$default" == "y" ]]; then
        read -p "$(echo -e ${CYAN}$prompt ${NC}[Y/n]: )" result
        result="${result:-y}"
    else
        read -p "$(echo -e ${CYAN}$prompt ${NC}[y/N]: )" result
        result="${result:-n}"
    fi

    [[ "$result" =~ ^[Yy] ]]
}

################################################################################
# Check Prerequisites
################################################################################

check_prerequisites() {
    log_header "Checking Prerequisites"

    if ! command_exists gh; then
        log_error "GitHub CLI (gh) not found"
        log_info "Install from: https://cli.github.com/"
        exit 1
    fi

    log_success "GitHub CLI found: $(gh --version | head -n1)"

    # Check if authenticated
    if ! gh auth status >/dev/null 2>&1; then
        log_warning "Not authenticated with GitHub"
        log_info "Authenticating..."
        gh auth login
    else
        log_success "Authenticated with GitHub"
    fi

    # Check if in a git repo
    if ! git rev-parse --git-dir >/dev/null 2>&1; then
        log_error "Not in a git repository"
        log_info "Run: git init"
        exit 1
    fi

    log_success "In git repository"
}

################################################################################
# Create Repository
################################################################################

create_repository() {
    log_header "GitHub Repository Setup"

    # Check if remote already exists
    if git remote get-url origin >/dev/null 2>&1; then
        local current_url=$(git remote get-url origin)
        log_info "Remote 'origin' already exists: $current_url"

        if ! prompt_yes_no "Update or recreate repository?"; then
            log_info "Skipping repository creation"
            return 0
        fi
    fi

    # Get repository details
    local repo_name=$(prompt "Repository name" "$(basename "$PWD")")
    local repo_desc=$(prompt "Repository description" "")
    local is_private

    if prompt_yes_no "Make repository private?"; then
        is_private="--private"
    else
        is_private="--public"
    fi

    log_info "Creating GitHub repository..."

    # Create repository
    if gh repo create "$repo_name" $is_private \
        --source=. \
        --description="$repo_desc" \
        --push; then
        log_success "Repository created and pushed"
        local repo_url=$(gh repo view --json url -q .url)
        log_info "Repository URL: $repo_url"
    else
        log_error "Failed to create repository"
        return 1
    fi
}

################################################################################
# Setup GitHub Labels
################################################################################

setup_labels() {
    log_header "Setting Up GitHub Labels"

    if ! prompt_yes_no "Setup GitHub labels for task organization?"; then
        log_info "Skipping label setup"
        return 0
    fi

    log_info "Creating labels..."

    # Define standard labels
    declare -A labels=(
        ["bug"]="d73a4a"
        ["feature"]="0e8a16"
        ["documentation"]="0075ca"
        ["enhancement"]="a2eeef"
        ["refactor"]="fbca04"
        ["testing"]="d4c5f9"
        ["infrastructure"]="ededed"
        ["security"]="ee0701"
        ["performance"]="f9d0c4"
        ["design"]="c5def5"
        ["high-priority"]="b60205"
        ["medium-priority"]="fbca04"
        ["low-priority"]="0e8a16"
        ["blocked"]="b60205"
        ["needs-research"]="d93f0b"
        ["good-first-issue"]="7057ff"
        ["help-wanted"]="008672"
    )

    for label in "${!labels[@]}"; do
        color="${labels[$label]}"
        if gh label create "$label" --color "$color" --force 2>/dev/null; then
            log_success "Created label: $label"
        fi
    done

    log_success "Labels configured"
}

################################################################################
# Setup Branch Protection
################################################################################

setup_branch_protection() {
    log_header "Branch Protection Setup"

    if ! prompt_yes_no "Setup branch protection for main branch?"; then
        log_info "Skipping branch protection"
        return 0
    fi

    log_info "Configuring branch protection..."

    local protect_args=""

    if prompt_yes_no "Require pull request reviews?" "n"; then
        protect_args="--require-pull-request"
    fi

    if prompt_yes_no "Require status checks to pass?" "n"; then
        protect_args="$protect_args --require-status-checks"
    fi

    # Apply protection (requires repository to be pushed first)
    if gh api repos/{owner}/{repo}/branches/main/protection \
        --method PUT \
        --field required_status_checks=null \
        --field enforce_admins=false \
        --field required_pull_request_reviews=null \
        --field restrictions=null 2>/dev/null; then
        log_success "Branch protection configured"
    else
        log_warning "Could not configure branch protection (may require push first)"
    fi
}

################################################################################
# Create Issue Templates
################################################################################

create_issue_templates() {
    log_header "GitHub Issue Templates"

    if ! prompt_yes_no "Create issue templates?"; then
        log_info "Skipping issue templates"
        return 0
    fi

    mkdir -p .github/ISSUE_TEMPLATE

    # Bug report template
    cat > .github/ISSUE_TEMPLATE/bug_report.md << 'EOF'
---
name: Bug Report
about: Report a bug or issue
title: '[BUG] '
labels: bug
assignees: ''
---

## Description

A clear and concise description of the bug.

## Steps to Reproduce

1. Go to '...'
2. Click on '....'
3. Scroll down to '....'
4. See error

## Expected Behavior

What you expected to happen.

## Actual Behavior

What actually happened.

## Environment

- OS: [e.g. macOS 12.0]
- Browser/Version: [e.g. Chrome 96]
- Version: [e.g. 1.0.0]

## Additional Context

Add any other context about the problem here.
EOF

    # Feature request template
    cat > .github/ISSUE_TEMPLATE/feature_request.md << 'EOF'
---
name: Feature Request
about: Suggest a new feature
title: '[FEATURE] '
labels: feature
assignees: ''
---

## Problem Statement

What problem does this feature solve? Who benefits?

## Proposed Solution

Describe your proposed solution.

## Alternatives Considered

What alternatives have you considered?

## Additional Context

Add any other context or screenshots about the feature request here.
EOF

    # Task template
    cat > .github/ISSUE_TEMPLATE/task.md << 'EOF'
---
name: Task
about: Create a task or work item
title: ''
labels: ''
assignees: ''
---

## Description

What needs to be done?

## Acceptance Criteria

- [ ] Criterion 1
- [ ] Criterion 2
- [ ] Criterion 3

## Dependencies

- [ ] Task #1
- [ ] Task #2

## Additional Notes

Any additional context or information.
EOF

    log_success "Issue templates created in .github/ISSUE_TEMPLATE/"
}

################################################################################
# Create GitHub Actions Workflow
################################################################################

create_github_actions() {
    log_header "GitHub Actions Setup"

    if ! prompt_yes_no "Create GitHub Actions CI/CD workflow?"; then
        log_info "Skipping GitHub Actions setup"
        return 0
    fi

    mkdir -p .github/workflows

    # Detect project type and create appropriate workflow
    if [[ -f "package.json" ]]; then
        create_node_workflow
    elif [[ -f "pyproject.toml" ]] || [[ -f "setup.py" ]]; then
        create_python_workflow
    else
        log_warning "Could not detect project type, creating generic workflow"
        create_generic_workflow
    fi

    log_success "GitHub Actions workflow created"
}

create_python_workflow() {
    cat > .github/workflows/ci.yml << 'EOF'
name: CI

on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

jobs:
  test:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        python-version: ["3.10", "3.11", "3.12"]

    steps:
    - uses: actions/checkout@v4

    - name: Set up Python ${{ matrix.python-version }}
      uses: actions/setup-python@v4
      with:
        python-version: ${{ matrix.python-version }}

    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install -e ".[dev]"

    - name: Lint
      run: |
        make check || true

    - name: Run tests
      run: |
        make test

    - name: Upload coverage
      uses: codecov/codecov-action@v3
      with:
        file: ./coverage.xml
        fail_ci_if_error: false
EOF
    log_success "Created Python CI workflow"
}

create_node_workflow() {
    cat > .github/workflows/ci.yml << 'EOF'
name: CI

on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

jobs:
  test:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        node-version: [18.x, 20.x]

    steps:
    - uses: actions/checkout@v4

    - name: Use Node.js ${{ matrix.node-version }}
      uses: actions/setup-node@v4
      with:
        node-version: ${{ matrix.node-version }}

    - name: Install dependencies
      run: npm ci

    - name: Lint
      run: npm run lint || true

    - name: Run tests
      run: npm test

    - name: Build
      run: npm run build || true
EOF
    log_success "Created Node.js CI workflow"
}

create_generic_workflow() {
    cat > .github/workflows/ci.yml << 'EOF'
name: CI

on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

jobs:
  build:
    runs-on: ubuntu-latest

    steps:
    - uses: actions/checkout@v4

    - name: Run tests
      run: |
        # Add your test commands here
        echo "Configure your test commands"
EOF
    log_success "Created generic CI workflow"
}

################################################################################
# Create Pull Request Template
################################################################################

create_pr_template() {
    log_header "Pull Request Template"

    if ! prompt_yes_no "Create pull request template?"; then
        log_info "Skipping PR template"
        return 0
    fi

    mkdir -p .github

    cat > .github/PULL_REQUEST_TEMPLATE.md << 'EOF'
## Description

Brief description of changes.

## Type of Change

- [ ] Bug fix
- [ ] New feature
- [ ] Breaking change
- [ ] Documentation update
- [ ] Refactoring
- [ ] Performance improvement

## Related Issues

Fixes #(issue number)

## Changes Made

- Change 1
- Change 2
- Change 3

## Testing

- [ ] Unit tests pass
- [ ] Integration tests pass
- [ ] Manual testing completed

## Checklist

- [ ] Code follows project style guidelines
- [ ] Self-review completed
- [ ] Comments added for complex code
- [ ] Documentation updated
- [ ] No new warnings generated
- [ ] Tests added/updated
- [ ] All tests passing

## Screenshots (if applicable)

## Additional Notes
EOF

    log_success "PR template created in .github/PULL_REQUEST_TEMPLATE.md"
}

################################################################################
# Main
################################################################################

main() {
    clear
    echo -e "${MAGENTA}"
    cat << 'EOF'
╔═══════════════════════════════════════════════════════════════════╗
║                                                                   ║
║           GitHub Repository Initialization                        ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝
EOF
    echo -e "${NC}"

    check_prerequisites
    create_repository
    setup_labels
    setup_branch_protection
    create_issue_templates
    create_pr_template
    create_github_actions

    log_header "GitHub Setup Complete!"
    echo ""
    log_success "Your repository is configured and ready to use"
    echo ""
    log_info "Repository: $(gh repo view --json url -q .url 2>/dev/null || echo 'Not available')"
    echo ""
    log_info "Next steps:"
    echo "  1. Review .github/ directory"
    echo "  2. Customize GitHub Actions workflows"
    echo "  3. Invite collaborators if needed"
    echo "  4. Configure repository settings on GitHub"
    echo ""
}

main "$@"
