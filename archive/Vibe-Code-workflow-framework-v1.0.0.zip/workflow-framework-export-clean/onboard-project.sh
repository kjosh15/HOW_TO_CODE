#!/usr/bin/env bash
set -euo pipefail

################################################################################
# Project Onboarding Questionnaire
#
# This interactive script asks comprehensive questions about your project
# and generates a functional specification document to guide development.
#
# Output:
#   - PROJECT-SPEC.md: Comprehensive functional specification
#   - CONTEXT.md: Initial project context
#   - Initial backlog tasks
#
################################################################################

VERSION="1.0.0"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m'

# Storage for answers
declare -A ANSWERS

# Logging
log_info() { echo -e "${BLUE}ℹ${NC} $1"; }
log_success() { echo -e "${GREEN}✓${NC} $1"; }
log_warning() { echo -e "${YELLOW}⚠${NC} $1"; }
log_section() {
    echo ""
    echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${MAGENTA}📋 $1${NC}"
    echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo ""
}

# Prompt functions
ask() {
    local key="$1"
    local question="$2"
    local default="${3:-}"
    local result

    if [[ -n "$default" ]]; then
        read -p "$(echo -e ${CYAN}$question ${NC}[${default}]: )" result
        ANSWERS[$key]="${result:-$default}"
    else
        read -p "$(echo -e ${CYAN}$question: ${NC})" result
        ANSWERS[$key]="$result"
    fi
}

ask_multiline() {
    local key="$1"
    local question="$2"
    local lines=()

    echo -e "${CYAN}$question${NC}"
    echo -e "${YELLOW}(Enter a blank line when done)${NC}"

    while IFS= read -r line; do
        [[ -z "$line" ]] && break
        lines+=("$line")
    done

    ANSWERS[$key]=$(printf "%s\n" "${lines[@]}")
}

ask_list() {
    local key="$1"
    local question="$2"
    local items=()

    echo -e "${CYAN}$question${NC}"
    echo -e "${YELLOW}(Enter items one per line, blank line when done)${NC}"

    while IFS= read -r item; do
        [[ -z "$item" ]] && break
        items+=("- $item")
    done

    ANSWERS[$key]=$(printf "%s\n" "${items[@]}")
}

ask_choice() {
    local key="$1"
    local question="$2"
    shift 2
    local options=("$@")

    echo -e "${CYAN}$question${NC}"
    for i in "${!options[@]}"; do
        echo "  $((i+1)). ${options[$i]}"
    done

    local choice
    while true; do
        read -p "$(echo -e ${CYAN}Enter choice [1-${#options[@]}]: ${NC})" choice
        if [[ "$choice" =~ ^[0-9]+$ ]] && [ "$choice" -ge 1 ] && [ "$choice" -le "${#options[@]}" ]; then
            ANSWERS[$key]="${options[$((choice-1))]}"
            break
        else
            log_warning "Invalid choice, try again"
        fi
    done
}

ask_yes_no() {
    local key="$1"
    local question="$2"
    local result

    read -p "$(echo -e ${CYAN}$question ${NC}[y/N]: )" result
    result="${result:-n}"

    if [[ "$result" =~ ^[Yy] ]]; then
        ANSWERS[$key]="Yes"
    else
        ANSWERS[$key]="No"
    fi
}

################################################################################
# Questionnaire Sections
################################################################################

section_project_basics() {
    log_section "Project Basics"

    ask "project_name" "What is your project name?"
    ask "project_tagline" "One-line description/tagline?"
    ask_multiline "project_description" "Detailed project description?"
    ask "project_goal" "What is the primary goal of this project?"

    ask_choice "project_type" "What type of project is this?" \
        "Web Application (SaaS, dashboard, etc.)" \
        "API/Backend Service" \
        "CLI Tool" \
        "Library/Framework" \
        "Mobile App" \
        "Desktop App" \
        "Data Pipeline/ETL" \
        "Other"

    ask_choice "project_stage" "What stage is this project in?" \
        "Idea/Concept (nothing built yet)" \
        "Planning/Design (specs being created)" \
        "Early Development (MVP in progress)" \
        "Active Development (features being added)" \
        "Maintenance (stable, bug fixes only)" \
        "Refactor/Rebuild (existing code being improved)"
}

section_target_audience() {
    log_section "Target Audience & Users"

    ask "target_users" "Who are the primary users/customers?"
    ask "user_count_estimate" "Expected number of users?" "Unknown"
    ask "user_expertise" "What is their technical expertise level?" "Mixed"
    ask_multiline "user_pain_points" "What problems are you solving for them?"
    ask "user_value_prop" "What's your unique value proposition?"
}

section_technical_stack() {
    log_section "Technical Stack & Architecture"

    ask_choice "primary_language" "Primary programming language?" \
        "Python" \
        "JavaScript/TypeScript" \
        "Go" \
        "Rust" \
        "Java/Kotlin" \
        "C#/.NET" \
        "Ruby" \
        "PHP" \
        "Other"

    if [[ "${ANSWERS[project_type]}" == *"Web"* ]] || [[ "${ANSWERS[project_type]}" == *"API"* ]]; then
        ask_choice "backend_framework" "Backend framework?" \
            "FastAPI (Python)" \
            "Django (Python)" \
            "Flask (Python)" \
            "Express.js (Node)" \
            "Next.js (Full-stack)" \
            "Rails (Ruby)" \
            "Spring Boot (Java)" \
            "ASP.NET Core (C#)" \
            "Other/None" \
            "Not applicable"

        ask_choice "frontend_framework" "Frontend framework?" \
            "React" \
            "Vue.js" \
            "Svelte" \
            "Next.js" \
            "Angular" \
            "Vanilla JS" \
            "Not applicable (API only)" \
            "Other"
    fi

    ask_choice "database" "Primary database?" \
        "PostgreSQL" \
        "MySQL/MariaDB" \
        "MongoDB" \
        "SQLite" \
        "Redis" \
        "Firebase" \
        "DynamoDB" \
        "Multiple databases" \
        "None yet" \
        "Other"

    ask_yes_no "needs_auth" "Does your project need user authentication?"

    if [[ "${ANSWERS[needs_auth]}" == "Yes" ]]; then
        ask_choice "auth_type" "What type of authentication?" \
            "Email + Password (JWT)" \
            "OAuth (Google, GitHub, etc.)" \
            "SSO (SAML, OIDC)" \
            "API Keys" \
            "Multiple methods" \
            "Not decided yet"
    fi

    ask_yes_no "needs_realtime" "Need real-time features (WebSockets, live updates)?"
    ask_yes_no "needs_background_jobs" "Need background job processing?"
    ask_yes_no "needs_search" "Need full-text search capabilities?"
    ask_yes_no "needs_file_storage" "Need file/media storage (uploads, assets)?"
}

section_features_requirements() {
    log_section "Core Features & Requirements"

    ask_list "must_have_features" "List MUST-HAVE features for MVP (minimum viable product):"
    echo ""
    ask_list "nice_to_have_features" "List NICE-TO-HAVE features (can come later):"
    echo ""
    ask_list "out_of_scope" "What is explicitly OUT OF SCOPE (not building):"
}

section_constraints() {
    log_section "Constraints & Priorities"

    ask_choice "timeline" "What is your timeline?" \
        "Urgent (days to weeks)" \
        "Normal (weeks to months)" \
        "Flexible (months+)" \
        "No timeline / exploring"

    ask_choice "priority" "What's most important?" \
        "Speed to market (ship fast)" \
        "Code quality (maintainable, tested)" \
        "Scalability (handle growth)" \
        "Cost efficiency (minimize spend)" \
        "User experience (polish, design)" \
        "Balanced (all equally important)"

    ask_choice "team_size" "Team size (including you)?" \
        "Solo (just me)" \
        "Small (2-3 people)" \
        "Medium (4-10 people)" \
        "Large (10+ people)"

    ask "budget_constraint" "Any budget constraints?" "None specified"
    ask "performance_requirements" "Performance requirements (if any)?" "Standard web performance"
}

section_deployment() {
    log_section "Deployment & Infrastructure"

    ask_choice "deployment_target" "Where will this be deployed?" \
        "Local development only (for now)" \
        "Cloud (AWS, GCP, Azure)" \
        "Platform-as-a-Service (Heroku, Render, Fly.io)" \
        "Container platform (Docker, Kubernetes)" \
        "Serverless (Lambda, Cloud Functions)" \
        "VPS (DigitalOcean, Linode)" \
        "On-premise / self-hosted" \
        "Not decided yet"

    ask_yes_no "needs_ci_cd" "Want CI/CD (automated testing & deployment)?"
    ask_yes_no "needs_monitoring" "Need monitoring & observability (logs, metrics, alerts)?"
    ask_yes_no "needs_docker" "Plan to use Docker for development/deployment?"
}

section_quality_testing() {
    log_section "Quality & Testing Strategy"

    ask_choice "testing_approach" "Testing strategy?" \
        "Comprehensive (unit, integration, e2e)" \
        "Pragmatic (integration tests mainly)" \
        "Minimal (critical paths only)" \
        "Manual testing only" \
        "Not sure yet"

    ask_yes_no "needs_type_checking" "Want static type checking (TypeScript, mypy, etc.)?"
    ask_yes_no "needs_linting" "Want code linting/formatting (ESLint, Ruff, Prettier)?"
    ask_yes_no "needs_code_review" "Plan to do code reviews (PR workflow)?"
}

section_documentation() {
    log_section "Documentation & Collaboration"

    ask_yes_no "needs_api_docs" "Need API documentation (OpenAPI/Swagger)?"
    ask_yes_no "needs_user_docs" "Need user documentation (guides, tutorials)?"
    ask_yes_no "needs_architecture_docs" "Want architecture decision records (ADRs)?"

    ask_choice "collaboration_style" "How will you collaborate?" \
        "Solo developer (no collaboration)" \
        "Pair programming with AI" \
        "Small team with async communication" \
        "Team with regular meetings" \
        "Open source (public contributions)"
}

section_success_metrics() {
    log_section "Success Metrics & Goals"

    ask "success_definition" "How do you define success for this project?"
    ask "mvp_definition" "What is the absolute minimum viable product?"
    ask_list "success_metrics" "What metrics will you track (if any):"
    echo ""
    ask "timeline_mvp" "When do you want MVP ready?" "No specific date"
}

section_risks_concerns() {
    log_section "Risks, Concerns & Questions"

    ask_multiline "biggest_risk" "What's your biggest risk or concern?"
    ask_multiline "unknown_areas" "What areas are you unsure about?"
    ask_multiline "need_research" "What needs research before starting?"
}

################################################################################
# Generate Specification Document
################################################################################

generate_spec() {
    local spec_file="PROJECT-SPEC.md"

    log_section "Generating Specification"

    cat > "$spec_file" << EOF
# Project Specification: ${ANSWERS[project_name]}

**Generated**: $(date +"%Y-%m-%d")
**Version**: 1.0.0
**Status**: Draft

---

## Executive Summary

### Project Overview
${ANSWERS[project_description]}

**Tagline**: ${ANSWERS[project_tagline]}

**Primary Goal**: ${ANSWERS[project_goal]}

**Project Type**: ${ANSWERS[project_type]}

**Current Stage**: ${ANSWERS[project_stage]}

### Value Proposition
${ANSWERS[user_value_prop]}

---

## Target Audience

**Primary Users**: ${ANSWERS[target_users]}

**Expected Scale**: ${ANSWERS[user_count_estimate]}

**User Expertise Level**: ${ANSWERS[user_expertise]}

### User Pain Points
${ANSWERS[user_pain_points]}

---

## Technical Architecture

### Technology Stack

**Primary Language**: ${ANSWERS[primary_language]}

EOF

    # Conditional sections based on project type
    if [[ -v ANSWERS[backend_framework] ]]; then
        cat >> "$spec_file" << EOF
**Backend Framework**: ${ANSWERS[backend_framework]}

**Frontend Framework**: ${ANSWERS[frontend_framework]}

EOF
    fi

    cat >> "$spec_file" << EOF
**Database**: ${ANSWERS[database]}

### Infrastructure & Services

**Authentication**: ${ANSWERS[needs_auth]:-No}
EOF

    if [[ "${ANSWERS[needs_auth]}" == "Yes" ]]; then
        cat >> "$spec_file" << EOF
- Type: ${ANSWERS[auth_type]}
EOF
    fi

    cat >> "$spec_file" << EOF

**Real-time Features**: ${ANSWERS[needs_realtime]:-No}

**Background Jobs**: ${ANSWERS[needs_background_jobs]:-No}

**Full-text Search**: ${ANSWERS[needs_search]:-No}

**File Storage**: ${ANSWERS[needs_file_storage]:-No}

**Deployment Target**: ${ANSWERS[deployment_target]}

**Docker**: ${ANSWERS[needs_docker]:-No}

**CI/CD**: ${ANSWERS[needs_ci_cd]:-No}

**Monitoring**: ${ANSWERS[needs_monitoring]:-No}

---

## Features & Requirements

### MUST-HAVE Features (MVP)
${ANSWERS[must_have_features]}

### NICE-TO-HAVE Features (Post-MVP)
${ANSWERS[nice_to_have_features]}

### Out of Scope
${ANSWERS[out_of_scope]}

---

## Constraints & Priorities

**Timeline**: ${ANSWERS[timeline]}

**Top Priority**: ${ANSWERS[priority]}

**Team Size**: ${ANSWERS[team_size]}

**Budget Constraints**: ${ANSWERS[budget_constraint]}

**Performance Requirements**: ${ANSWERS[performance_requirements]}

**MVP Target Date**: ${ANSWERS[timeline_mvp]}

---

## Quality & Testing

**Testing Strategy**: ${ANSWERS[testing_approach]}

**Type Checking**: ${ANSWERS[needs_type_checking]:-No}

**Linting/Formatting**: ${ANSWERS[needs_linting]:-No}

**Code Review Process**: ${ANSWERS[needs_code_review]:-No}

---

## Documentation

**API Documentation**: ${ANSWERS[needs_api_docs]:-No}

**User Documentation**: ${ANSWERS[needs_user_docs]:-No}

**Architecture Decisions**: ${ANSWERS[needs_architecture_docs]:-No}

**Collaboration Style**: ${ANSWERS[collaboration_style]}

---

## Success Criteria

### Definition of Success
${ANSWERS[success_definition]}

### Minimum Viable Product (MVP)
${ANSWERS[mvp_definition]}

### Metrics to Track
${ANSWERS[success_metrics]}

---

## Risks & Open Questions

### Biggest Risks
${ANSWERS[biggest_risk]}

### Areas of Uncertainty
${ANSWERS[unknown_areas]}

### Research Needed
${ANSWERS[need_research]}

---

## Next Steps

Based on this specification, the recommended next steps are:

1. **Context Gathering**: Run \`/agents context-gatherer\` to analyze existing codebase (if any)

2. **Technical Research**: Investigate the areas marked "needs research" above

3. **Architecture Design**: Create detailed architecture specification
   - Data models and schema
   - API endpoints and contracts
   - Authentication/authorization flow
   - Deployment architecture

4. **Implementation Planning**: Break down MVP features into tasks
   - Create epic tasks for each major feature
   - Define acceptance criteria
   - Estimate effort and dependencies

5. **Development Setup**: Initialize development environment
   - Setup development dependencies
   - Configure linting/testing tools
   - Setup CI/CD pipeline (if needed)

6. **Start Building**: Begin with highest priority MVP features

---

## Appendix: Answers Summary

<details>
<summary>Click to expand full questionnaire responses</summary>

EOF

    # Add all answers as a reference
    for key in "${!ANSWERS[@]}"; do
        echo "- **$key**: ${ANSWERS[$key]}" >> "$spec_file"
    done

    cat >> "$spec_file" << EOF

</details>

---

**Document Status**: This is a living document. Update as decisions are made and requirements evolve.

**Review Schedule**: Review and update weekly during planning, monthly during development.
EOF

    log_success "Specification generated: $spec_file"
}

################################################################################
# Generate Initial Context Document
################################################################################

generate_context() {
    local context_file="CONTEXT.md"

    if [[ -f "$context_file" ]]; then
        log_warning "CONTEXT.md already exists, skipping generation"
        return
    fi

    log_section "Generating Context Document"

    cat > "$context_file" << EOF
# ${ANSWERS[project_name]} - Project Context

**Date**: $(date +"%Y-%m-%d")
**Specification Version**: 1.0.0
**Implementation Status**: ${ANSWERS[project_stage]}

---

## Project Context

### Overview

${ANSWERS[project_description]}

**Core Value Proposition**: ${ANSWERS[user_value_prop]}

### Structure

#### Core Components

*To be defined during architecture design phase*

#### Key Patterns

*To be documented as patterns emerge during development*

#### Dependencies

*To be documented when dependencies are added*

#### Entry Points

*To be documented when application structure is created*

### Technology Stack

**Language/Framework**:
- ${ANSWERS[primary_language]}
EOF

    if [[ -v ANSWERS[backend_framework] ]]; then
        cat >> "$context_file" << EOF
- ${ANSWERS[backend_framework]}
- ${ANSWERS[frontend_framework]}
EOF
    fi

    cat >> "$context_file" << EOF

**Database**:
- ${ANSWERS[database]}

**Testing**:
- ${ANSWERS[testing_approach]} approach
EOF

    if [[ "${ANSWERS[needs_type_checking]}" == "Yes" ]]; then
        echo "- Static type checking enabled" >> "$context_file"
    fi

    cat >> "$context_file" << EOF

**Deployment**:
- ${ANSWERS[deployment_target]}
EOF

    if [[ "${ANSWERS[needs_docker]}" == "Yes" ]]; then
        echo "- Docker containerization" >> "$context_file"
    fi

    if [[ "${ANSWERS[needs_ci_cd]}" == "Yes" ]]; then
        echo "- CI/CD pipeline" >> "$context_file"
    fi

    cat >> "$context_file" << EOF

### Architecture

**Pattern**: *To be defined*

**Data Flow**: *To be documented*

**State Management**: *To be documented*

**Error Handling**: *To be documented*

### Constraints

#### Technical Constraints

1. **Timeline**: ${ANSWERS[timeline]}
2. **Team Size**: ${ANSWERS[team_size]}
3. **Budget**: ${ANSWERS[budget_constraint]}
4. **Performance**: ${ANSWERS[performance_requirements]}

#### Business Constraints

*To be documented as business requirements are clarified*

#### Performance Considerations

${ANSWERS[performance_requirements]}

#### Security Considerations

EOF

    if [[ "${ANSWERS[needs_auth]}" == "Yes" ]]; then
        cat >> "$context_file" << EOF
1. **Authentication**: ${ANSWERS[auth_type]}
2. **Authorization**: *To be defined*
3. **Data Privacy**: *To be defined*
EOF
    else
        echo "*Security requirements to be defined*" >> "$context_file"
    fi

    cat >> "$context_file" << EOF

### Current State

#### What Works

*To be documented as features are implemented*

#### Known Issues

*To be tracked in backlog*

#### Areas Needing Attention

**Immediate**:
- Research: ${ANSWERS[need_research]}
- Clarify: ${ANSWERS[unknown_areas]}

**High Priority**:
*To be determined during planning*

**Medium Priority**:
*To be determined during planning*

**Low Priority**:
*To be determined during planning*

#### Recent Changes

- $(date +"%Y-%m-%d"): Initial project specification created
- Project onboarding completed

### Project-Specific Conventions

**Code Style**:
EOF

    if [[ "${ANSWERS[needs_linting]}" == "Yes" ]]; then
        echo "- Linting and formatting enforced" >> "$context_file"
    fi

    if [[ "${ANSWERS[needs_type_checking]}" == "Yes" ]]; then
        echo "- Static type checking required" >> "$context_file"
    fi

    cat >> "$context_file" << EOF

**Testing Strategy**:
- ${ANSWERS[testing_approach]}

**Commit Guidelines**:
- Follow conventional commits
- Reference task IDs when applicable
- Keep commits focused and atomic

### Questions and Uncertainties

#### Critical Questions (Blocking Implementation)

${ANSWERS[unknown_areas]}

#### Areas Needing Research

${ANSWERS[need_research]}

---

## Next Steps

See PROJECT-SPEC.md for detailed next steps.

**Recommended First Actions**:

1. Review PROJECT-SPEC.md thoroughly
2. Research critical unknowns
3. Run \`/agents context-gatherer\` if codebase exists
4. Create initial architecture specification
5. Break down MVP into tasks

---

**Document Version**: 1.0
**Last Updated**: $(date +"%Y-%m-%d")
**Next Review**: After architecture design
EOF

    log_success "Context document generated: $context_file"
}

################################################################################
# Generate Initial Tasks
################################################################################

generate_initial_tasks() {
    log_section "Generating Initial Tasks"

    if ! command -v backlog >/dev/null 2>&1; then
        log_warning "backlog command not found, skipping task creation"
        log_info "Install backlog.md and create tasks manually from PROJECT-SPEC.md"
        return
    fi

    log_info "Creating initial planning tasks..."

    # Task 1: Research
    if [[ -n "${ANSWERS[need_research]}" ]]; then
        backlog task create "Research: Critical Unknowns" \
            --description "Research areas identified in onboarding: ${ANSWERS[need_research]}" \
            --status "To Do" \
            --label "research" \
            --priority "high" || true
    fi

    # Task 2: Architecture Design
    backlog task create "Design System Architecture" \
        --description "Create detailed architecture specification based on PROJECT-SPEC.md" \
        --status "To Do" \
        --label "design" \
        --priority "high" || true

    # Task 3: Development Environment
    backlog task create "Setup Development Environment" \
        --description "Initialize development environment with required tools and dependencies" \
        --status "To Do" \
        --label "infrastructure" \
        --priority "high" || true

    # Task 4: Break Down MVP
    backlog task create "Break Down MVP into Tasks" \
        --description "Create detailed task breakdown for MVP features from PROJECT-SPEC.md" \
        --status "To Do" \
        --label "planning" \
        --priority "high" || true

    log_success "Initial tasks created in backlog"
    log_info "View tasks with: backlog board"
}

################################################################################
# Generate Next Steps Guide
################################################################################

generate_next_steps_guide() {
    local guide_file="GETTING-STARTED.md"

    cat > "$guide_file" << EOF
# Getting Started with ${ANSWERS[project_name]}

Welcome! This guide will help you get started with development.

## What Just Happened?

You completed the project onboarding questionnaire. The following files were generated:

- **PROJECT-SPEC.md** - Comprehensive functional specification
- **CONTEXT.md** - Initial project context document
- **GETTING-STARTED.md** - This file
- **Initial backlog tasks** - Starting tasks in \`backlog/\`

## Immediate Next Steps

### 1. Review the Specification

Read **PROJECT-SPEC.md** carefully. This is your project's blueprint.

\`\`\`bash
cat PROJECT-SPEC.md
\`\`\`

### 2. Research Critical Unknowns

Address items listed in "Research Needed":

${ANSWERS[need_research]}

### 3. View Your Task Board

\`\`\`bash
backlog board
\`\`\`

### 4. Start Context Gathering (If Code Exists)

If you have existing code:

\`\`\`
# In Claude Code or compatible AI tool
/agents context-gatherer
\`\`\`

If starting from scratch:

\`\`\`
# In Claude Code
/agents spec-writer "System Architecture"
\`\`\`

## Recommended Workflow

### Phase 1: Planning (Days 1-3)

1. ✓ Complete onboarding (done!)
2. Review PROJECT-SPEC.md
3. Research unknowns
4. Create architecture specification
5. Break down MVP into detailed tasks

### Phase 2: Setup (Days 3-5)

1. Setup development environment
2. Initialize project structure
3. Configure tools (linting, testing, etc.)
4. Setup CI/CD if needed
5. Create initial commit

### Phase 3: Development (Weeks 1-N)

1. Start with highest priority MVP features
2. Follow the agent workflow:
   - context-gatherer → spec-writer → implementation-planner → backlog-manager
3. Build, test, commit regularly
4. Update CONTEXT.md as project evolves

### Phase 4: Launch

1. Complete all MVP features
2. Run full test suite
3. Deploy to ${ANSWERS[deployment_target]}
4. Monitor and iterate

## Agent Workflow Quick Reference

\`\`\`bash
# Morning standup
/agents backlog-manager "Daily standup"

# Before starting a feature
/agents context-gatherer  # Understand codebase
/agents spec-writer "[Feature Name]"  # Write spec
/agents implementation-planner "SPEC-[name].md"  # Create plan
/agents backlog-manager "Create tasks from PLAN-[name].md"  # Create tasks

# After completing tasks
/agents context-maintainer  # Document learnings
\`\`\`

## Useful Commands

\`\`\`bash
# Task management
backlog board              # View kanban board
backlog task create        # Create new task
backlog task list          # List all tasks
backlog browser            # Open web UI

# View documentation
cat PROJECT-SPEC.md        # Project specification
cat CONTEXT.md             # Project context
cat WORKFLOW.md            # Workflow details
cat BEST-PRACTICES.md      # Best practices
\`\`\`

## Success Metrics

Track these to measure progress:

${ANSWERS[success_metrics]}

## MVP Definition

Your minimum viable product is:

${ANSWERS[mvp_definition]}

Target date: ${ANSWERS[timeline_mvp]}

## Questions or Issues?

- Review **WORKFLOW.md** for workflow questions
- Review **BEST-PRACTICES.md** for development guidelines
- Update **PROJECT-SPEC.md** as requirements evolve
- Use backlog tasks to track work

## Priority Matrix

Based on your input, here's your priority:

**Most Important**: ${ANSWERS[priority]}
**Timeline**: ${ANSWERS[timeline]}
**Team Size**: ${ANSWERS[team_size]}

This means you should focus on:
EOF

    # Add specific recommendations based on priorities
    case "${ANSWERS[priority]}" in
        "Speed to market"*)
            cat >> "$guide_file" << EOF
- Get to MVP as fast as possible
- Use proven technologies
- Minimize custom code
- Ship early, iterate later
EOF
            ;;
        "Code quality"*)
            cat >> "$guide_file" << EOF
- Write comprehensive tests
- Document all decisions
- Follow strict code review process
- Refactor regularly
EOF
            ;;
        "Scalability"*)
            cat >> "$guide_file" << EOF
- Design for scale from day 1
- Choose scalable infrastructure
- Load test early and often
- Plan for caching and optimization
EOF
            ;;
        "Cost efficiency"*)
            cat >> "$guide_file" << EOF
- Use serverless where possible
- Minimize third-party services
- Optimize for resource usage
- Monitor and optimize costs
EOF
            ;;
        "User experience"*)
            cat >> "$guide_file" << EOF
- Invest in design and UX
- Test with real users early
- Polish before shipping
- Focus on performance and accessibility
EOF
            ;;
    esac

    cat >> "$guide_file" << EOF

---

**Generated**: $(date +"%Y-%m-%d")

Good luck building! 🚀
EOF

    log_success "Getting started guide generated: $guide_file"
}

################################################################################
# Main Flow
################################################################################

main() {
    clear
    echo -e "${MAGENTA}"
    cat << 'EOF'
╔═══════════════════════════════════════════════════════════════════╗
║                                                                   ║
║           Project Onboarding Questionnaire                        ║
║                                                                   ║
║   This questionnaire will help generate a comprehensive           ║
║   functional specification for your project.                      ║
║                                                                   ║
║   Take your time and answer thoughtfully. You can always          ║
║   update the generated documents later.                           ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝
EOF
    echo -e "${NC}"

    log_info "Estimated time: 10-15 minutes"
    echo ""

    read -p "$(echo -e ${CYAN}Press Enter to begin...${NC})"

    # Run all sections
    section_project_basics
    section_target_audience
    section_technical_stack
    section_features_requirements
    section_constraints
    section_deployment
    section_quality_testing
    section_documentation
    section_success_metrics
    section_risks_concerns

    # Generate outputs
    generate_spec
    generate_context
    generate_initial_tasks
    generate_next_steps_guide

    # Final summary
    log_section "Onboarding Complete!"
    echo ""
    log_success "Generated files:"
    echo "  📄 PROJECT-SPEC.md - Functional specification"
    echo "  📄 CONTEXT.md - Project context"
    echo "  📄 GETTING-STARTED.md - Next steps guide"
    echo "  📋 Initial backlog tasks"
    echo ""
    log_info "Next steps:"
    echo "  1. Review PROJECT-SPEC.md"
    echo "  2. Read GETTING-STARTED.md"
    echo "  3. Run: backlog board"
    echo "  4. Start with context gathering or architecture design"
    echo ""
    log_success "Happy building! 🚀"
}

main "$@"
