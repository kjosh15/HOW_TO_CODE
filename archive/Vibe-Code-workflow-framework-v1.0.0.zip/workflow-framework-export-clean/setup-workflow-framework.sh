#!/usr/bin/env bash
set -euo pipefail

################################################################################
# Workflow Framework Setup Script
#
# This script sets up a comprehensive AI-assisted development workflow framework
# in any directory. It includes:
# - Backlog.md task management
# - AI agent workflow system
# - GitHub repository initialization
# - Project onboarding questionnaire
# - Documentation templates
#
# Usage:
#   ./setup-workflow-framework.sh [PROJECT_NAME]
#
# Example:
#   ./setup-workflow-framework.sh "My Awesome Project"
#
################################################################################

VERSION="1.0.0"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Logging functions
log_info() {
    echo -e "${BLUE}ℹ${NC} $1"
}

log_success() {
    echo -e "${GREEN}✓${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}⚠${NC} $1"
}

log_error() {
    echo -e "${RED}✗${NC} $1"
}

log_header() {
    echo ""
    echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${MAGENTA}$1${NC}"
    echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
}

# Check if a command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Prompt for input with default value
prompt_with_default() {
    local prompt="$1"
    local default="$2"
    local result

    read -p "$(echo -e ${CYAN}$prompt ${NC}[${default}]: )" result
    echo "${result:-$default}"
}

# Prompt for yes/no
prompt_yes_no() {
    local prompt="$1"
    local default="${2:-y}"
    local result

    if [[ "$default" == "y" ]]; then
        read -p "$(echo -e ${CYAN}$prompt ${NC}[Y/n]: )" result
        result="${result:-y}"
    else
        read -p "$(echo -e ${CYAN}$prompt ${NC}[y/N]: )" result
        result="${result:-n}"
    fi

    [[ "$result" =~ ^[Yy] ]]
}

################################################################################
# Check Prerequisites
################################################################################

check_prerequisites() {
    log_header "Checking Prerequisites"

    local missing_tools=()

    # Required tools
    if ! command_exists git; then
        missing_tools+=("git")
    else
        log_success "git found: $(git --version | head -n1)"
    fi

    # Check for package managers (at least one needed for backlog.md)
    local has_package_manager=false
    if command_exists npm; then
        log_success "npm found: $(npm --version)"
        has_package_manager=true
    fi
    if command_exists bun; then
        log_success "bun found: $(bun --version)"
        has_package_manager=true
    fi
    if command_exists brew; then
        log_success "brew found: $(brew --version | head -n1)"
        has_package_manager=true
    fi

    if [[ "$has_package_manager" == false ]]; then
        log_warning "No package manager found (npm, bun, or brew)"
        log_warning "Backlog.md installation will need to be done manually"
    fi

    # Check if backlog.md is already installed
    if command_exists backlog; then
        log_success "backlog.md found: $(backlog --version 2>/dev/null || echo 'version unknown')"
    else
        log_warning "backlog.md not installed (will prompt for installation)"
    fi

    # Optional but recommended tools
    if command_exists gh; then
        log_success "GitHub CLI (gh) found: $(gh --version | head -n1)"
    else
        log_info "GitHub CLI (gh) not found - GitHub integration will be limited"
    fi

    if [[ ${#missing_tools[@]} -gt 0 ]]; then
        log_error "Missing required tools: ${missing_tools[*]}"
        log_error "Please install them and try again"
        exit 1
    fi

    log_success "All required prerequisites met"
}

################################################################################
# Install Backlog.md
################################################################################

install_backlog_md() {
    if command_exists backlog; then
        log_success "backlog.md already installed"
        return 0
    fi

    log_header "Installing Backlog.md"

    if ! prompt_yes_no "Install backlog.md task management tool?"; then
        log_warning "Skipping backlog.md installation"
        log_warning "You'll need to install it manually later: https://github.com/MrLesk/Backlog.md"
        return 1
    fi

    # Determine which package manager to use
    if command_exists npm; then
        log_info "Installing via npm..."
        npm install -g backlog.md
    elif command_exists bun; then
        log_info "Installing via bun..."
        bun add -g backlog.md
    elif command_exists brew; then
        log_info "Installing via Homebrew..."
        brew install backlog-md
    else
        log_error "No package manager available. Please install backlog.md manually:"
        log_info "  npm: npm install -g backlog.md"
        log_info "  bun: bun add -g backlog.md"
        log_info "  brew: brew install backlog-md"
        return 1
    fi

    if command_exists backlog; then
        log_success "backlog.md installed successfully"
        return 0
    else
        log_error "backlog.md installation failed"
        return 1
    fi
}

################################################################################
# Initialize Git Repository
################################################################################

init_git_repo() {
    log_header "Git Repository Setup"

    if [[ -d ".git" ]]; then
        log_info "Git repository already initialized"
        return 0
    fi

    if ! prompt_yes_no "Initialize Git repository?"; then
        log_warning "Skipping Git initialization"
        return 1
    fi

    git init -b main
    log_success "Git repository initialized with 'main' branch"

    # Create .gitignore if it doesn't exist
    if [[ ! -f ".gitignore" ]]; then
        cat > .gitignore << 'EOF'
# OS files
.DS_Store
Thumbs.db

# IDE
.vscode/
.idea/
*.swp
*.swo
*~

# Environment
.env
.env.local
*.local

# Dependencies
node_modules/
venv/
__pycache__/
*.pyc

# Build artifacts
dist/
build/
*.egg-info/

# Logs
*.log
logs/

# Temporary files
tmp/
temp/
EOF
        log_success "Created .gitignore"
    fi
}

################################################################################
# Initialize Backlog.md
################################################################################

init_backlog() {
    local project_name="$1"

    log_header "Backlog.md Initialization"

    if [[ -d "backlog" ]]; then
        log_info "Backlog already exists"
        if ! prompt_yes_no "Reinitialize backlog?"; then
            return 0
        fi
    fi

    if ! command_exists backlog; then
        log_warning "backlog.md not installed, skipping initialization"
        log_info "Install it later and run: backlog init \"$project_name\""
        return 1
    fi

    log_info "Initializing backlog for: $project_name"

    # Create backlog structure manually since we want specific config
    mkdir -p backlog/tasks backlog/work

    # Create config.yml
    cat > backlog/config.yml << EOF
project_name: "$project_name"
default_status: "To Do"
statuses: ["To Do", "In Progress", "Done"]
labels: ["bug", "feature", "documentation", "refactor", "testing"]
milestones: []
date_format: yyyy-mm-dd
max_column_width: 20
auto_open_browser: true
default_port: 6420
remote_operations: true
auto_commit: false
zero_padded_ids: 3
bypass_git_hooks: false
check_active_branches: true
active_branch_days: 30
EOF

    log_success "Backlog initialized with configuration"
}

################################################################################
# Create Workflow Documentation
################################################################################

create_workflow_docs() {
    log_header "Creating Workflow Documentation"

    # This will call separate scripts to create each template file
    # For now, we'll create basic versions

    log_info "Creating WORKFLOW.md..."
    if [[ -f "$SCRIPT_DIR/templates/WORKFLOW.md" ]]; then
        cp "$SCRIPT_DIR/templates/WORKFLOW.md" WORKFLOW.md
        log_success "WORKFLOW.md created from template"
    else
        log_warning "Template not found, will create basic version"
        # Create inline if template doesn't exist
        create_workflow_md_inline
    fi

    log_info "Creating AGENTS.md..."
    if [[ -f "$SCRIPT_DIR/templates/AGENTS.md" ]]; then
        cp "$SCRIPT_DIR/templates/AGENTS.md" AGENTS.md
        log_success "AGENTS.md created from template"
    else
        create_agents_md_inline
    fi

    log_info "Creating CLAUDE.md..."
    if [[ -f "$SCRIPT_DIR/templates/CLAUDE.md" ]]; then
        cp "$SCRIPT_DIR/templates/CLAUDE.md" CLAUDE.md
        log_success "CLAUDE.md created from template"
    else
        create_claude_md_inline
    fi

    log_info "Creating BACKLOG.md..."
    if [[ -f "$SCRIPT_DIR/templates/BACKLOG.md" ]]; then
        cp "$SCRIPT_DIR/templates/BACKLOG.md" BACKLOG.md
        log_success "BACKLOG.md created from template"
    else
        create_backlog_md_inline
    fi

    log_info "Creating FRAMEWORK-README.md..."
    create_framework_readme

    log_success "Workflow documentation created"
}

# Inline template creators (fallbacks)
create_workflow_md_inline() {
    cat > WORKFLOW.md << 'EOF'
# Workflow-Aware Agent System

See templates directory or NTWRKR source for complete workflow documentation.

This framework uses specialized AI agents to guide development from idea to implementation.
EOF
    log_success "Created basic WORKFLOW.md"
}

create_agents_md_inline() {
    cat > AGENTS.md << 'EOF'
# Repository Guidelines

See templates directory or NTWRKR source for complete agent documentation.

This file defines the specialized agents used in the workflow.
EOF
    log_success "Created basic AGENTS.md"
}

create_claude_md_inline() {
    cat > CLAUDE.md << 'EOF'
# CLAUDE.md

This file provides guidance to Claude Code when working with code in this repository.

## Project Structure

- Update this section with your project structure

## Commands

- Update this section with your project commands

## Workflow

This project uses the AI-Assisted Development Workflow Framework.
See WORKFLOW.md and AGENTS.md for details.
EOF
    log_success "Created basic CLAUDE.md"
}

create_backlog_md_inline() {
    cat > BACKLOG.md << 'EOF'
<!-- BACKLOG.MD MCP GUIDELINES START -->

<CRITICAL_INSTRUCTION>

## BACKLOG WORKFLOW INSTRUCTIONS

This project uses Backlog.md MCP for all task and project management activities.

**CRITICAL RESOURCE**: Read `backlog://workflow/overview` to understand when and how to use Backlog for this project.

</CRITICAL_INSTRUCTION>

<!-- BACKLOG.MD MCP GUIDELINES END -->
EOF
    log_success "Created basic BACKLOG.md"
}

create_framework_readme() {
    cat > FRAMEWORK-README.md << 'EOF'
# AI-Assisted Development Workflow Framework

This project uses a comprehensive workflow framework for AI-assisted development.

## Quick Start

1. Read WORKFLOW.md to understand the agent workflow
2. Read AGENTS.md to understand each agent's role
3. Read CLAUDE.md for Claude Code specific instructions
4. Use `backlog board` to see your task board
5. Run the onboarding questionnaire: `./onboard-project.sh`

## Documentation

- **WORKFLOW.md** - Complete workflow patterns and agent chain
- **AGENTS.md** - Agent definitions and capabilities
- **CLAUDE.md** - AI assistant instructions
- **BACKLOG.md** - Task management integration
- **BEST-PRACTICES.md** - Best practices guide

## Commands

- `backlog board` - View task kanban board
- `backlog task create "Title"` - Create a new task
- `backlog task list` - List all tasks
- `backlog browser` - Open web UI

## Workflow Overview

```
💡 Idea → 📚 Context → 📝 Spec → 🗺️ Plan → 📋 Tasks → ⚙️ Build → ✅ Done → 📖 Learn
```

See WORKFLOW.md for complete details.
EOF
    log_success "Created FRAMEWORK-README.md"
}

################################################################################
# Run Onboarding Questionnaire
################################################################################

run_onboarding() {
    log_header "Project Onboarding"

    if ! prompt_yes_no "Run interactive project onboarding questionnaire?"; then
        log_info "Skipping onboarding - you can run it later with: ./onboard-project.sh"
        return 0
    fi

    if [[ -f "$SCRIPT_DIR/onboard-project.sh" ]]; then
        chmod +x "$SCRIPT_DIR/onboard-project.sh"
        "$SCRIPT_DIR/onboard-project.sh"
    else
        log_warning "onboard-project.sh not found in $SCRIPT_DIR"
        log_info "You can run onboarding manually later"
    fi
}

################################################################################
# Setup GitHub Repository
################################################################################

setup_github() {
    log_header "GitHub Repository Setup"

    if ! command_exists gh; then
        log_warning "GitHub CLI (gh) not installed"
        log_info "Install it from: https://cli.github.com/"
        log_info "Or setup GitHub manually"
        return 1
    fi

    if ! prompt_yes_no "Create GitHub repository?"; then
        log_info "Skipping GitHub setup"
        log_info "You can create a repository manually later"
        return 0
    fi

    if [[ -f "$SCRIPT_DIR/github-init.sh" ]]; then
        chmod +x "$SCRIPT_DIR/github-init.sh"
        "$SCRIPT_DIR/github-init.sh"
    else
        log_warning "github-init.sh not found, will create repository manually"
        create_github_repo_inline
    fi
}

create_github_repo_inline() {
    local repo_name
    local repo_desc
    local is_private

    repo_name=$(prompt_with_default "Repository name" "$(basename "$PWD")")
    repo_desc=$(prompt_with_default "Repository description" "")

    if prompt_yes_no "Make repository private?"; then
        is_private="--private"
    else
        is_private="--public"
    fi

    log_info "Creating GitHub repository..."

    if gh repo create "$repo_name" $is_private --source=. --description="$repo_desc" --push; then
        log_success "GitHub repository created and pushed"
        log_info "Repository URL: $(gh repo view --json url -q .url)"
    else
        log_error "Failed to create GitHub repository"
        return 1
    fi
}

################################################################################
# Initial Commit
################################################################################

create_initial_commit() {
    log_header "Creating Initial Commit"

    if ! prompt_yes_no "Create initial commit with framework files?"; then
        log_info "Skipping initial commit"
        return 0
    fi

    git add .
    git commit -m "Initial commit: Setup AI-Assisted Development Workflow Framework

- Added backlog.md task management
- Added workflow documentation (WORKFLOW.md, AGENTS.md)
- Added AI assistant instructions (CLAUDE.md)
- Added framework README and best practices
- Initialized project structure

Framework version: $VERSION"

    log_success "Initial commit created"

    if git remote get-url origin >/dev/null 2>&1; then
        if prompt_yes_no "Push to remote?"; then
            git push -u origin main
            log_success "Pushed to remote"
        fi
    fi
}

################################################################################
# Main Setup Flow
################################################################################

main() {
    local project_name="${1:-}"

    # Print header
    clear
    echo -e "${MAGENTA}"
    cat << 'EOF'
╔═══════════════════════════════════════════════════════════════════╗
║                                                                   ║
║   AI-Assisted Development Workflow Framework Setup               ║
║   Version 1.0.0                                                   ║
║                                                                   ║
║   This script will set up a comprehensive workflow system for    ║
║   AI-assisted development in your project.                       ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝
EOF
    echo -e "${NC}"

    # Get project name if not provided
    if [[ -z "$project_name" ]]; then
        project_name=$(prompt_with_default "Project name" "$(basename "$PWD")")
    fi

    log_info "Setting up framework for: $project_name"
    log_info "Target directory: $PWD"
    echo ""

    if ! prompt_yes_no "Continue with setup?"; then
        log_info "Setup cancelled"
        exit 0
    fi

    # Run setup steps
    check_prerequisites
    install_backlog_md
    init_git_repo
    init_backlog "$project_name"
    create_workflow_docs
    setup_github
    run_onboarding
    create_initial_commit

    # Print success summary
    log_header "Setup Complete!"
    echo ""
    log_success "Framework successfully installed in: $PWD"
    echo ""
    echo -e "${CYAN}Next Steps:${NC}"
    echo "  1. Review FRAMEWORK-README.md for overview"
    echo "  2. Read WORKFLOW.md to understand the agent workflow"
    echo "  3. Run: backlog board (to view task board)"
    echo "  4. Run: ./onboard-project.sh (if you skipped it)"
    echo "  5. Start with: /agents context-gatherer (in Claude Code)"
    echo ""
    echo -e "${CYAN}Useful Commands:${NC}"
    echo "  backlog board              # View task kanban"
    echo "  backlog task create        # Create new task"
    echo "  backlog browser            # Open web UI"
    echo "  ./onboard-project.sh       # Run onboarding"
    echo ""
    log_info "Happy building! 🚀"
}

# Run main function
main "$@"
