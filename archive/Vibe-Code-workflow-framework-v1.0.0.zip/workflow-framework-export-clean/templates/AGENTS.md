# Repository Guidelines

## Project Structure & Module Organization
The Python package lives in `src/ntwrkr`; add new modules here and expose public APIs via `src/ntwrkr/__init__.py`. Tests sit in `tests/` and should mirror the package layout. Documentation sources are under `docs/` and rendered through MkDocs. The Makefile and `docker-compose*.yml` files orchestrate local services, while `CLAUDE.md`, `GEMINI.md`, and `WORKFLOW.md` capture automation playbooks for repository agents.

## Build, Test, and Development Commands
Run `make install` the first time to sync dependencies with `uv` and install pre-commit hooks. Use `make check` before opening a PR; it validates the lock file, runs Ruff, applies the pre-commit suite, executes `mypy`, and audits dependencies with deptry. Execute `make test` (or `uv run pytest --cov=src`) for the unit suite and coverage XML. Run `make docs` to serve MkDocs locally, and `make up`/`make down` to manage the Dockerized data stack when developing integrations.

## Coding Style & Naming Conventions
Target Python 3.10+ with full type hints—`mypy` rejects untyped definitions by default. Keep modules and functions in `snake_case`, classes in `PascalCase`, and constants uppercase. Ruff formatting targets a 120-character line length; rely on `uv run pre-commit run -a` to auto-fix formatting and lint issues. Security- and bug-prone patterns are flagged through Ruff’s `S`, `B`, and `TRY` rule sets—resolve or justify suppressions inline.

## Testing Guidelines
Write `pytest` tests in files named `test_<feature>.py` and mirror the source hierarchy for easy discovery. Prefer fixture reuse over ad-hoc setup, and assert error handling with `pytest.raises`. Maintain coverage on critical modules (`make test` emits `coverage.xml`); when validating across Python versions, execute `uv run tox`. Update MkDocs examples when adding behavior that affects documented flows.

## Commit & Pull Request Guidelines
Existing history favors concise, sentence-style subjects; prefer imperative, lower-case verbs (`add compose profile`, `fix graph seed`). Reference Backlog task IDs when applicable and group related changes per commit. Pull requests should summarize intent, note any Docker or docs impacts, and include the command output from `make check`/`make test`. Request reviewers listed in `CONTRIBUTING.md` and confirm new CLI flags, services, or agents are documented.

## Agent & Automation Notes
Review `CLAUDE.md`, `GEMINI.md`, and `WORKFLOW.md` before delegating to LLM agents; they describe expectations, secrets hygiene, and escalation paths. Capture automation-related work in Backlog.md, keep prompts reproducible, and store any generated configuration under version control rather than in external tools.
