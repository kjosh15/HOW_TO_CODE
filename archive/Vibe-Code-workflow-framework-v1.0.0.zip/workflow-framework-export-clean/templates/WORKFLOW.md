# Workflow-Aware Agent System

This document describes how our specialized agents work together in a semi-automated workflow to guide development from idea to implementation.

## Overview

Each agent now includes **Workflow Integration** sections that enable them to:
- ✅ Check prerequisites and refuse to run if not met
- ✅ Suggest the next agent with specific commands
- ✅ Create handoff files for smooth transitions
- ✅ Detect workflow state and guide you
- ✅ Batch multiple operations in one call

## Agent Chain Flow

```
context-gatherer → spec-writer → implementation-planner → backlog-manager
                                                               ↓
                                                    [Implementation Work]
                                                               ↓
                                                      backlog-manager
                                                               ↓
                                                    context-maintainer
```

## What Each Agent Does Now

### 1. Context-Gatherer (Enhanced)

**New Capabilities:**
- Checks for existing CONTEXT.md before recreating
- Scans for existing specs and tasks
- Creates HANDOFF-context.md with recommendations
- Suggests next agent based on project state

**On Completion:**
```
✅ Context gathered. Next: `/agents spec-writer` for [suggested feature]
```

### 2. Spec-Writer (Enhanced)

**New Capabilities:**
- Pre-flight check: Verifies CONTEXT.md exists
- Warns if no context documentation found
- Checks for duplicate specs
- Creates HANDOFF-spec-[name].md
- Suggests next agent based on complexity

**On Completion:**
```
✅ Spec complete: SPEC-[name].md

Next Step:
- High/Medium complexity: `/agents implementation-planner`
- Low complexity: `/agents backlog-manager`
```

### 3. Implementation-Planner (Enhanced)

**New Capabilities:**
- Verifies spec exists before planning
- Checks for duplicate tasks in backlog
- Creates HANDOFF-plan-[name].md
- Generates ready-to-execute task creation commands
- Provides dependency graph visualization

**On Completion:**
```
✅ Plan complete: PLAN-[name].md

Ready-to-run commands for backlog-manager:
[Shows all task creation commands]

Next: `/agents backlog-manager` "Create tasks from PLAN-[name].md"
```

### 4. Backlog-Manager (Enhanced)

**New Capabilities:**
- Auto-detects project state on every invocation
- Checks for specs/plans without tasks
- Identifies stale in-progress tasks
- Detects tasks with all ACs checked but not marked Done
- Generates daily standup reports
- Suggests next work based on priorities
- Detects pattern changes and suggests context updates

**Auto-Detection Examples:**

**No tasks exist:**
```
📋 No tasks found. Checking for specs...
Found: SPEC-authentication.md (no tasks created yet)

Recommended: Create tasks from spec
```

**All ACs checked:**
```
✅ task-38 has all ACs checked but status is "In Progress"
Should I mark as Done?
```

**Task complete with new patterns:**
```
✅ task-45 complete: Authentication system

Detected new patterns. Recommend:
`/agents context-maintainer` to document learnings
```

### 5. Context-Maintainer (Enhanced)

**New Capabilities:**
- Auto-discovers recently completed tasks
- Extracts patterns from implementation notes
- Creates LEARNING-LOG.md entries
- Suggests refactoring tasks when patterns should propagate
- Creates ADRs for significant decisions
- Updates multiple documentation sources

**Auto-Discovery:**
```bash
# Checks completed tasks
backlog task list -s Done --plain | head -5

# Analyzes implementation notes for:
- New patterns
- Dependencies changed
- Performance characteristics
- Technical debt
```

**Pattern Propagation:**
```
✅ task-45 introduced new auth middleware

Old pattern found in 8 files.
Should we create refactoring task? (Y/N)
```

## Workflow Templates

### New Feature Workflow

```bash
# 1. Understand the codebase (first time only)
/agents context-gatherer

# 2. Write specification
/agents spec-writer "[feature name]"

# 3. Create implementation plan (if complex)
/agents implementation-planner "SPEC-[name].md"

# 4. Create tasks from plan
/agents backlog-manager "Create tasks from PLAN-[name].md"

# 5. Implement in main Claude Code
# (work on tasks, mark ACs as complete)

# 6. Track progress
/agents backlog-manager "Check status and suggest next work"

# 7. Document learnings
/agents context-maintainer
```

### Daily Workflow

```bash
# Morning standup
/agents backlog-manager "Daily standup: what should I work on?"

# Work on tasks...

# Mark progress
backlog task edit [id] --check-ac 1 --check-ac 2

# End of day
/agents backlog-manager "Review today's progress"
```

### Weekly Review

```bash
/agents backlog-manager "Weekly review: check stale tasks, blockers, health report"
```

## Semi-Automation Features

### 1. Contextual Triggers

Agents recognize situations and provide guidance:

- ❌ No CONTEXT.md → "Run context-gatherer first"
- 📝 Spec without plan → "Run implementation-planner"
- 📋 Plan without tasks → "Let me create tasks"
- ✅ All ACs checked → "Ready to mark Done"
- 🔄 Pattern changes → "Run context-maintainer"

### 2. Batch Operations

```bash
# Morning workflow
/agents backlog-manager "Morning standup: update statuses and suggest priorities"

# Process all pending plans
/agents backlog-manager "Create tasks from all pending PLAN-*.md files"

# Weekly health check
/agents backlog-manager "Check for stale tasks, blockers, and generate report"
```

### 3. Smart Handoffs

Each agent creates a handoff file for the next:

- `HANDOFF-context.md` → Guides spec writing
- `HANDOFF-spec-[name].md` → Guides planning
- `HANDOFF-plan-[name].md` → Provides task commands
- `HANDOFF-context-update-[date].md` → Documents changes

### 4. Ready-to-Execute Commands

Implementation-planner generates commands for backlog-manager:

```bash
# Copy-paste ready task creation
backlog task create "Task 1" -d "..." --ac "..." --ac "..."
backlog task create "Task 2" -d "..." --ac "..." --dep task-[N]
```

## What Agents Check Automatically

### Context-Gatherer
- [ ] CONTEXT.md exists? (update vs create)
- [ ] Existing SPEC-*.md files?
- [ ] Backlog tasks exist?
- [ ] CHANGELOG-CONTEXT.md present?

### Spec-Writer
- [ ] CONTEXT.md exists?
- [ ] Duplicate specs?
- [ ] Related backlog tasks?
- [ ] Requirements clear?

### Implementation-Planner
- [ ] Spec file approved?
- [ ] Existing duplicate tasks?
- [ ] CONTEXT.md for patterns?
- [ ] Dependencies clear?

### Backlog-Manager
- [ ] Specs without tasks?
- [ ] Plans without tasks?
- [ ] Stale in-progress tasks?
- [ ] ACs checked but not Done?
- [ ] New patterns to document?

### Context-Maintainer
- [ ] Recent completed tasks?
- [ ] New patterns to document?
- [ ] Specs to mark complete?
- [ ] Technical debt to track?
- [ ] ADRs needed?

## Benefits of Workflow-Aware Agents

1. **Guided Development**: Agents suggest next steps automatically
2. **No Lost Work**: Handoff files ensure smooth transitions
3. **Proactive Management**: Auto-detection prevents forgotten tasks
4. **Knowledge Preservation**: Context updates happen automatically
5. **Reduced Cognitive Load**: Agents remember workflow state
6. **Batch Operations**: Handle multiple tasks in one invocation
7. **Pattern Propagation**: Technical improvements spread automatically

## Best Practices

1. **Morning Routine**
   ```bash
   /agents backlog-manager "Daily standup"
   ```

2. **After Completing Tasks**
   ```bash
   /agents context-maintainer
   ```

3. **Weekly Health Check**
   ```bash
   /agents backlog-manager "Weekly review"
   ```

4. **Before New Features**
   ```bash
   /agents context-gatherer  # If needed
   /agents spec-writer "[feature]"
   ```

5. **Let Agents Guide You**
   - Trust their recommendations
   - Follow the suggested next steps
   - Use the handoff files they create

## Reality Check

While agents can't run **independently**, they now:
- ✅ Guide you through the workflow
- ✅ Remember project state
- ✅ Suggest next actions
- ✅ Create transition documentation
- ✅ Detect when things are out of sync
- ✅ Provide ready-to-execute commands

This makes the workflow **feel** more automated while keeping you in control.
