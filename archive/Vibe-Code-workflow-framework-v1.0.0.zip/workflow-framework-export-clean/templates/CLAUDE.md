# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Commands

```bash
# Update these with your project-specific commands

# Example: Set up development environment
make install

# Example: Run tests
make test

# Example: Build project
make build
```

## Project Structure

Update this section with your project structure:

- `src/` - Source code
- `tests/` - Test files
- `docs/` - Documentation

## Dependencies

List key dependencies and their purpose here.

<!-- BACKLOG.MD MCP GUIDELINES START -->

<CRITICAL_INSTRUCTION>

## BACKLOG WORKFLOW INSTRUCTIONS

This project uses Backlog.md MCP for all task and project management activities.

**CRITICAL RESOURCE**: Read `backlog://workflow/overview` to understand when and how to use Backlog for this project.

- **First time working here?** Read the overview resource IMMEDIATELY to learn the workflow
- **Already familiar?** You should have the overview cached ("## Backlog.md Overview (MCP)")
- **When to read it**: BEFORE creating tasks, or when you're unsure whether to track work

The overview resource contains:
- Decision framework for when to create tasks
- Search-first workflow to avoid duplicates
- Links to detailed guides for task creation, execution, and completion
- MCP tools reference

You MUST read the overview resource to understand the complete workflow. The information is NOT summarized here.

</CRITICAL_INSTRUCTION>

<!-- BACKLOG.MD MCP GUIDELINES END -->

## TASK DOCUMENTATION WORKFLOW

Every task in the backlog MUST have comprehensive documentation that evolves as the task progresses.

### Task Folder Structure

Each task gets its own folder: `backlog/work/task-{id}/`

```
backlog/work/task-019.01/
├── context.md           # Task-specific context (what we know, what we need)
├── spec.md              # Detailed specification (what to build)
├── implementation.md    # Implementation plan and progress
└── decisions.md         # Key decisions made during implementation
```

### When to Create Task Documentation

1. **Before starting implementation** - Create the folder and initial files
2. **As you learn** - Update context.md with discoveries
3. **When planning** - Write spec.md before coding
4. **During implementation** - Track progress in implementation.md
5. **When making choices** - Document decisions in decisions.md

### File Templates and Guidelines

#### context.md
```markdown
# Task Context: [Task Title]

## Current Understanding
- What we know about the problem
- Relevant existing code
- Dependencies on other tasks

## Open Questions
- What we still need to figure out
- Areas of uncertainty

## Related Resources
- Links to relevant docs, specs, PRs
- Similar implementations
```

#### spec.md
```markdown
# Specification: [Task Title]

## Objective
What this task accomplishes

## Requirements
- Functional requirements
- Non-functional requirements
- Acceptance criteria (from backlog task)

## API/Interface Design
- Endpoints, functions, classes
- Input/output schemas
- Error handling

## Data Model Changes
- New tables/fields
- Migrations needed

## Testing Strategy
- Unit tests
- Integration tests
- Manual testing steps
```

#### implementation.md
```markdown
# Implementation Plan: [Task Title]

## Status: [Not Started | In Progress | Blocked | Complete]

## Approach
High-level strategy for implementation

## Steps
- [ ] Step 1: Create X
- [ ] Step 2: Implement Y
- [ ] Step 3: Test Z

## Progress Notes
### YYYY-MM-DD HH:MM
- What was done
- Challenges encountered
- Next steps

## Blockers
- Current blockers and mitigation strategies

## Completion Checklist
- [ ] All acceptance criteria met
- [ ] Tests written and passing
- [ ] Documentation updated
- [ ] Code reviewed
- [ ] CHANGELOG.md updated
```

#### decisions.md
```markdown
# Decisions: [Task Title]

## Decision Log

### [YYYY-MM-DD] Decision Title
**Context**: Why we needed to make a decision
**Options Considered**:
1. Option A - pros/cons
2. Option B - pros/cons
**Decision**: What we chose and why
**Consequences**: What this means going forward
```

### Global Documentation Files

These files track project-wide state and should be updated regularly:

#### CONTEXT.md (Project Root)
```markdown
# Project Context

## Current State
- What's implemented
- What's in progress
- Current architecture state

## Recent Changes
- Major changes in last 2 weeks
- Impact on project direction

## Active Decisions
- Architectural choices
- Technology decisions
- Process decisions

## Known Issues
- Technical debt
- Blockers
- Areas needing refactoring

## Next Priorities
- What's coming next
- Upcoming decisions needed
```

#### CHANGELOG.md (Project Root)
```markdown
# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

## [Unreleased]

### Added
- [task-XXX] Feature description

### Changed

### Fixed

### Removed

## [0.0.1] - YYYY-MM-DD

### Added
- Initial project structure
```

### Task Completion Workflow

Before marking a task as complete, you MUST:

1. **Update implementation.md** with final status and completion notes
2. **Update CHANGELOG.md** with changes made, linking to task file
3. **Update CONTEXT.md** if the task changed project architecture or state
4. **Update global docs** if task introduced new patterns or decisions
5. **Archive task work** - Task folder stays in backlog/work/ for reference

Example CHANGELOG entry:
```markdown
### Added
- [task-019.01](backlog/work/task-019.01/) Feature description
```

### Updating Documentation During Implementation

As you work on a task:

1. **Start of session**: Read task-*/context.md to understand where you left off
2. **During coding**: Update implementation.md progress notes frequently
3. **When blocked**: Document blockers immediately in implementation.md
4. **When deciding**: Add decisions to decisions.md with rationale
5. **End of session**: Update CONTEXT.md with current project state
6. **Task complete**: Update CHANGELOG.md before marking done

### Why This Matters

This documentation-driven approach ensures:
- **Continuity** - Anyone can pick up where you left off
- **Context preservation** - We don't lose knowledge between sessions
- **Decision tracking** - We remember why we made choices
- **Accountability** - Clear audit trail of work done
- **Learning** - Patterns and decisions become reusable knowledge

**Remember**: Documentation is not optional. If it's not documented, it didn't happen.

## AGENT WORKFLOW FOR TASKS

When starting work on any backlog task, follow this **required multi-agent workflow**:

See WORKFLOW.md for complete details on the agent workflow system.

### Quick Reference

```bash
# Morning standup
/agents backlog-manager "Daily standup"

# Before starting a feature
/agents context-gatherer  # Understand codebase
/agents spec-writer "[Feature Name]"  # Write spec (gets user approval)
/agents implementation-planner "SPEC-[name].md"  # Create plan
/agents backlog-manager "Create tasks from PLAN-[name].md"  # Create tasks

# After completing tasks
/agents context-maintainer  # Document learnings
```

See AGENTS.md for detailed agent descriptions and capabilities.

## Project-Specific Conventions

Update these sections for your project:

**Code Style**:
- Add your code style guidelines
- Linting/formatting tools
- Line length limits
- Naming conventions

**Testing Strategy**:
- Testing approach (unit, integration, e2e)
- Test framework
- Coverage requirements
- When to write tests

**Commit Guidelines**:
- Commit message format
- When to commit
- How to reference tasks

**Architecture Patterns**:
- Key architectural decisions
- Design patterns in use
- Technology choices
