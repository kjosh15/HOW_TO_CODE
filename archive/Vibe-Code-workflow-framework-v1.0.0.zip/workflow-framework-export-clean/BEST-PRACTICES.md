# Best Practices Guide

**Framework Version**: 1.0.0
**Last Updated**: 2025

A comprehensive guide to using the AI-Assisted Development Workflow Framework effectively.

---

## Table of Contents

- [Daily Workflow](#daily-workflow)
- [Task Management](#task-management)
- [Documentation](#documentation)
- [Agent Usage](#agent-usage)
- [Code Quality](#code-quality)
- [Common Pitfalls](#common-pitfalls)
- [Team Collaboration](#team-collaboration)

---

## Daily Workflow

### Morning Routine (5-10 minutes)

```bash
# 1. Pull latest changes (if team project)
git pull

# 2. Run daily standup
/agents backlog-manager "Daily standup"

# 3. Review your board
backlog board

# 4. Pick highest priority task
backlog task list --status "To Do" --sort priority
```

**Output**: Clear picture of what to work on today

### During Work (continuous)

1. **Start task**: Update status to "In Progress"
   ```bash
   backlog task edit task-042 --status "In Progress"
   ```

2. **Read task context**:
   ```bash
   cat backlog/work/task-042/spec.md
   cat backlog/work/task-042/implementation.md
   ```

3. **Work incrementally**:
   - Implement one piece at a time
   - Test frequently
   - Update `implementation.md` with progress notes
   - Check off acceptance criteria as you complete them

4. **Document decisions**:
   - When you make a choice, document it immediately
   - Add to `backlog/work/task-042/decisions.md`
   - Include context, options, and rationale

5. **Commit frequently**:
   ```bash
   git add .
   git commit -m "feat: Implement login endpoint [task-042]

   - Add POST /auth/login endpoint
   - Implement JWT token generation
   - Add input validation

   Acceptance criteria 1, 2 complete"
   ```

### End of Day (5-10 minutes)

```bash
# 1. Update progress on all active tasks
# Edit implementation.md files with session notes

# 2. Commit any work in progress
git add .
git commit -m "wip: Login endpoint [task-042]"

# 3. Review progress
/agents backlog-manager "Review today's progress"

# 4. Plan tomorrow (optional)
# Note next steps in implementation.md
```

### Weekly Review (30-60 minutes)

```bash
# 1. Run weekly review
/agents backlog-manager "Weekly review"

# 2. Capture learnings
/agents context-maintainer

# 3. Update project context
# Review and update CONTEXT.md

# 4. Clean up stale tasks
# Close or update old tasks

# 5. Plan next week
# Prioritize backlog
```

---

## Task Management

### Creating Tasks

#### ✅ Good Task

```markdown
---
id: task-042
title: Implement User Login Endpoint
status: To Do
priority: high
labels: [feature, authentication]
---

## Description

Create POST /auth/login endpoint that accepts email/password
and returns JWT token.

## Acceptance Criteria

- [ ] Endpoint accepts email and password
- [ ] Returns JWT token on success
- [ ] Returns 401 on invalid credentials
- [ ] Input validation works
- [ ] Tests pass with >80% coverage

## Dependencies

- task-041 (Database models must be complete)
```

#### ❌ Bad Task

```markdown
---
title: Login
---

Make login work.
```

**Why it's bad**:
- Too vague
- No acceptance criteria
- No dependencies noted
- Missing context

### Task Sizing

**Ideal task size**: 2-8 hours of work

**Too small**: "Add import statement" → Combine with related work
**Too large**: "Build authentication system" → Break into subtasks

**Breaking down large tasks**:

```bash
# Create epic
backlog task create "Epic: Authentication System" --label epic

# Create subtasks
backlog task create "Database models for users" --parent task-040
backlog task create "Login endpoint" --parent task-040 --dep task-041
backlog task create "Registration endpoint" --parent task-040 --dep task-041
backlog task create "Password reset flow" --parent task-040 --dep task-042
```

### Task States

Use three states consistently:

1. **To Do**: Ready to start, all dependencies met
2. **In Progress**: Currently working on it
3. **Done**: All ACs met, tests pass, docs updated, committed

**Never**:
- Have 5+ tasks "In Progress" (focus!)
- Mark "Done" with unchecked ACs
- Leave tasks in "In Progress" for >1 week without update

### Task Work Folders

Every non-trivial task should have `backlog/work/task-XXX/`:

**When to create**:
- ✅ New feature implementation
- ✅ Complex bug fix requiring investigation
- ✅ Refactoring multiple files
- ✅ Architecture decisions

**When to skip**:
- ❌ Trivial changes (typo fixes, simple updates)
- ❌ Documentation-only updates
- ❌ Dependency bumps

**What to include**:

```
backlog/work/task-042/
├── context.md          # What you know, what you need
├── spec.md             # What to build
├── implementation.md   # How to build it, progress
└── decisions.md        # Key decisions made
```

---

## Documentation

### The Documentation Hierarchy

1. **PROJECT-SPEC.md** - What you're building (mostly static)
2. **CONTEXT.md** - Current state of project (updated weekly/monthly)
3. **CHANGELOG.md** - What changed (updated with every task)
4. **backlog/work/*/spec.md** - Task-specific specs (per task)
5. **backlog/work/*/implementation.md** - Implementation notes (daily)
6. **backlog/work/*/decisions.md** - Design decisions (as made)

### Documentation Update Frequency

| Document | When to Update | Who Updates |
|----------|----------------|-------------|
| PROJECT-SPEC.md | Major scope changes | Spec-writer agent or manual |
| CONTEXT.md | Weekly or after major changes | Context-maintainer agent |
| CHANGELOG.md | Every completed task | You (required!) |
| Implementation.md | During work session (frequently) | You |
| Decisions.md | When making decisions | You (immediately) |

### Writing Good Documentation

#### Context.md (Task-Specific)

```markdown
# Task Context: Implement Login Endpoint

## Current Understanding

### What Exists
- User model in database with email, password_hash
- Database connection working
- FastAPI app with /health endpoint

### What's Missing
- No authentication endpoints yet
- No JWT library integrated
- No password hashing setup

### Related Code
- src/models/user.py - User model
- src/db/session.py - Database session management

## Open Questions

- Which JWT library? (Research: PyJWT vs python-jose)
- Token expiration time? (Propose: 24 hours)
- Refresh token needed for MVP? (Propose: No, post-MVP)

## Dependencies

- task-041: Database models (DONE)
- PyJWT library (to be added)

## Resources

- FastAPI JWT tutorial: https://...
- Security best practices: https://...
```

#### Spec.md (Task-Specific)

```markdown
# Specification: User Login Endpoint

## Objective

Create a secure login endpoint that authenticates users and returns JWT tokens.

## Requirements

### Functional Requirements

FR1: Accept email and password via POST request
FR2: Validate credentials against database
FR3: Generate JWT token on successful auth
FR4: Return 401 on failed auth
FR5: Return structured error messages

### Non-Functional Requirements

NFR1: Response time < 500ms (database is local)
NFR2: Password never logged or exposed
NFR3: Token expires in 24 hours
NFR4: Use BCrypt for password comparison

## API Design

### Endpoint: POST /auth/login

**Request**:
```json
{
  "email": "user@example.com",
  "password": "secretpassword"
}
```

**Response (200 OK)**:
```json
{
  "access_token": "eyJ0eXAiOiJKV1QiLCJhbGc...",
  "token_type": "bearer",
  "expires_in": 86400
}
```

**Response (401 Unauthorized)**:
```json
{
  "detail": "Invalid credentials"
}
```

### Security Considerations

1. Use BCrypt for password verification
2. Don't reveal whether email exists
3. Rate limit: 5 attempts per IP per minute
4. Log failed attempts

## Testing Strategy

- Unit test: JWT token generation
- Unit test: Password verification
- Integration test: Full login flow
- Integration test: Invalid credentials
- Security test: SQL injection attempts
```

#### Implementation.md

```markdown
# Implementation Plan: User Login Endpoint

## Status: In Progress

## Approach

1. Add PyJWT dependency
2. Create authentication service
3. Implement /auth/login endpoint
4. Add tests
5. Update documentation

## Steps

- [x] Step 1: Add PyJWT to dependencies
- [x] Step 2: Create src/services/auth.py
- [ ] Step 3: Implement verify_password function
- [ ] Step 4: Implement create_access_token function
- [ ] Step 5: Create /auth/login route
- [ ] Step 6: Add input validation
- [ ] Step 7: Write unit tests
- [ ] Step 8: Write integration tests
- [ ] Step 9: Update CHANGELOG.md

## Progress Notes

### 2025-01-15 14:30
- Added PyJWT==2.8.0 to dependencies
- Created auth service module
- Started with password verification function

**Challenge**: BCrypt vs Argon2 decision
**Decision**: Using BCrypt (more mature, widely supported)
**Documented in**: decisions.md

**Next**: Implement token generation

### 2025-01-15 16:00
- Implemented verify_password with BCrypt
- Created access token generation
- Tests passing

**Blocker**: Need to decide on token expiration
**Action**: Asked user, waiting for response

## Completion Checklist

- [ ] All ACs checked off
- [ ] Tests passing (unit + integration)
- [ ] CHANGELOG.md updated
- [ ] No new linting warnings
- [ ] Decisions documented
```

#### Decisions.md

```markdown
# Decisions: User Login Endpoint

## Decision Log

### [2025-01-15] Use BCrypt for Password Hashing

**Context**: Need to choose password hashing algorithm. Options are BCrypt, Argon2, or PBKDF2.

**Options Considered**:

1. **BCrypt**
   - Pros: Mature, widely used, good Python library (bcrypt)
   - Cons: Slower than Argon2

2. **Argon2**
   - Pros: Modern, won PHC 2015, more secure
   - Cons: Less widely adopted, newer library

3. **PBKDF2**
   - Pros: Standard library support
   - Cons: Less secure than BCrypt/Argon2

**Decision**: Use BCrypt

**Rationale**:
- Proven track record in production
- Excellent Python library support
- Team familiar with it
- More important to ship than to have theoretical best security
- Can migrate to Argon2 later if needed

**Consequences**:
- Use `bcrypt` library for hashing
- Document minimum cost factor (12) in settings
- Future migration path available

### [2025-01-15] JWT Expiration: 24 Hours

**Context**: Need to decide token expiration time.

**Options**:
1. 15 minutes (high security)
2. 1 hour (balanced)
3. 24 hours (convenient)
4. 7 days (very convenient)

**Decision**: 24 hours

**Rationale**:
- MVP doesn't have refresh tokens yet
- Don't want users re-logging constantly
- Can reduce later when refresh tokens added
- Acceptable risk for MVP phase

**Consequences**:
- Set in settings as `JWT_EXPIRATION_HOURS = 24`
- Add refresh token support in task-050 (planned)
- Document this as a known security tradeoff
```

### CHANGELOG.md Best Practices

Follow [Keep a Changelog](https://keepachangelog.com/) format:

```markdown
# Changelog

## [Unreleased]

### Added
- [task-042](backlog/work/task-042/) User login endpoint with JWT authentication
- BCrypt password hashing

### Changed
- Updated authentication flow to use JWT tokens

### Fixed

### Removed

## [0.1.0] - 2025-01-10

### Added
- [task-040] Initial project structure
- [task-041] Database models for users
```

**Rules**:
- Link to task work folder
- Use past tense for completed features
- Group by Added/Changed/Fixed/Removed
- Link to task IDs
- Update before marking task done

---

## Agent Usage

### When to Use Each Agent

#### context-gatherer

**Use when**:
- ✅ First time in a project
- ✅ Starting a major refactor
- ✅ Context is unclear or outdated
- ✅ Before writing a spec for complex feature

**Don't use when**:
- ❌ You just ran it recently (< 1 week ago)
- ❌ For trivial changes
- ❌ Context is fresh and clear

**Best practices**:
- Run it thoroughly the first time
- Update CONTEXT.md manually for small changes
- Re-run monthly or after major milestones

#### spec-writer

**Use when**:
- ✅ Starting any new feature
- ✅ Requirements are unclear
- ✅ Architecture decision needed
- ✅ Building something complex

**Don't use when**:
- ❌ Spec already exists
- ❌ Trivial change (typo fix, minor update)
- ❌ Just implementing from existing spec

**Best practices**:
- Provide all context upfront
- Answer questions thoughtfully
- **Always review and approve** before proceeding
- Update spec if requirements change

#### implementation-planner

**Use when**:
- ✅ Have an approved spec
- ✅ Feature is complex (>1 day of work)
- ✅ Need to break down an epic
- ✅ Multiple dependencies or risks

**Don't use when**:
- ❌ Simple, obvious implementation
- ❌ No spec exists (run spec-writer first)
- ❌ Already have a plan

**Best practices**:
- Ensure spec is complete first
- Review plan before creating tasks
- Adjust timeline estimates based on experience
- Update plan if implementation reveals issues

#### backlog-manager

**Use when**:
- ✅ Daily standup (every morning)
- ✅ Creating tasks from a plan
- ✅ Reviewing progress (end of day/week)
- ✅ Need to see next priorities

**Don't use when**:
- ❌ Just need to check one task (use `backlog task list`)
- ❌ Simple task update (edit directly)

**Best practices**:
- Let it auto-detect state
- Follow its suggestions
- Use for regular check-ins
- Trust its priority recommendations

#### context-maintainer

**Use when**:
- ✅ After completing major tasks
- ✅ Weekly/monthly reviews
- ✅ Pattern emerged that should be documented
- ✅ Architecture changed

**Don't use when**:
- ❌ No work completed recently
- ❌ Nothing significant changed
- ❌ Just updated docs manually

**Best practices**:
- Run after sprint/milestone
- Let it discover patterns
- Review its suggestions
- Create refactoring tasks it suggests

### Agent Workflow Patterns

#### Pattern 1: New Feature (Full Flow)

```bash
# 1. Understand
/agents context-gatherer

# 2. Define (with approval)
/agents spec-writer "Feature Name"
# ... review and approve spec ...

# 3. Plan
/agents implementation-planner "SPEC-feature-name.md"

# 4. Execute
/agents backlog-manager "Create tasks from PLAN-feature-name.md"
# ... implement tasks ...

# 5. Learn
/agents context-maintainer
```

#### Pattern 2: Quick Win (Shortened)

For simple, clear features:

```bash
# 1. Quick context check (optional)
cat CONTEXT.md

# 2. Write spec
/agents spec-writer "Simple Feature"
# ... approve ...

# 3. Create task directly
backlog task create "Implement simple feature" \
  --description "..." \
  --ac "..." --ac "..." \
  --label feature

# 4. Implement

# 5. Update docs manually
```

#### Pattern 3: Bug Fix

```bash
# 1. Create bug task
backlog task create "Fix: Login returns 500" \
  --label bug --priority high

# 2. Investigate (document in implementation.md)

# 3. Fix and test

# 4. Update CHANGELOG

# 5. Close task
```

---

## Code Quality

### Testing

**Required**:
- All new features must have tests
- All bug fixes must have regression tests
- Tests must pass before committing

**Testing pyramid**:
```
     /\      Unit tests (many, fast)
    /  \
   /----\    Integration tests (some, medium)
  /------\   E2E tests (few, slow)
```

**When to write tests**:
1. **Before coding** (TDD): For complex logic
2. **During coding**: For most features
3. **After coding**: When exploring/prototyping

**What to test**:
- ✅ Business logic
- ✅ API endpoints
- ✅ Database operations
- ✅ Error handling
- ✅ Edge cases

**What not to test**:
- ❌ Third-party libraries
- ❌ Framework internals
- ❌ Trivial getters/setters

### Code Review

**Self-review checklist** (before committing):

- [ ] Code works and tests pass
- [ ] Follows project style guide
- [ ] No commented-out code
- [ ] No debug print statements
- [ ] Error handling included
- [ ] Documentation updated
- [ ] CHANGELOG.md updated
- [ ] Secrets not committed
- [ ] Dependencies documented

**Peer review checklist** (if team):

- [ ] Understand what changed and why
- [ ] Logic is sound
- [ ] Tests are adequate
- [ ] No security issues
- [ ] Performance acceptable
- [ ] Follows conventions

### Commits

**Good commit message**:
```
feat: Add user login endpoint [task-042]

- Implement POST /auth/login
- Add JWT token generation
- Add password verification with BCrypt
- Add input validation

Acceptance criteria 1-4 complete.
Tests passing with 85% coverage.
```

**Bad commit message**:
```
stuff
```

**Commit frequency**:
- ✅ After each logical unit of work
- ✅ After tests pass
- ✅ End of day (even if WIP)
- ❌ Not every 5 minutes
- ❌ Not once per week

---

## Common Pitfalls

### Pitfall 1: Skipping Spec Approval

**Mistake**: Running spec-writer but not reviewing the spec before implementing

**Consequence**: Build the wrong thing, waste time

**Solution**: Always read and approve specs. Ask questions if unclear.

### Pitfall 2: Stale Documentation

**Mistake**: Not updating CONTEXT.md or CHANGELOG.md

**Consequence**: Future you (or teammates) are confused

**Solution**:
- Update CHANGELOG.md before marking tasks done (required)
- Run context-maintainer weekly
- Review CONTEXT.md monthly

### Pitfall 3: Too Many WIP Tasks

**Mistake**: Starting 5+ tasks simultaneously

**Consequence**: Nothing gets done, context switching overhead

**Solution**:
- Limit WIP to 1-2 tasks
- Finish before starting next
- Use backlog-manager to focus

### Pitfall 4: No Task Work Folders

**Mistake**: Not creating backlog/work/task-XXX/ for complex tasks

**Consequence**: Lose context, decisions forgotten

**Solution**:
- Create work folder for any non-trivial task
- Document as you go, not after
- Review past work folders to remember patterns

### Pitfall 5: Ignoring Agent Suggestions

**Mistake**: Running agents but not following recommendations

**Consequence**: Wasted effort, agents become useless

**Solution**:
- Trust the agent workflow
- If you disagree, document why
- Refine prompts if output isn't helpful

### Pitfall 6: Forgetting Dependencies

**Mistake**: Starting task before dependencies are done

**Consequence**: Blocked, wasted time

**Solution**:
- Always check `backlog task list --status "To Do"` for ready tasks
- Mark dependencies explicitly
- Backlog-manager will suggest next work

---

## Team Collaboration

### For Solo Developers

- Still follow the workflow (future you is a teammate)
- Document decisions as if explaining to someone else
- Run agents regularly for structure
- Commit message discipline matters

### For Small Teams (2-5 people)

**Morning**:
- Each person runs `/agents backlog-manager "Daily standup"`
- Quick sync call (5-10 min)
- Share what you're working on

**During day**:
- Update task status when you start/finish
- Document in implementation.md
- PR reviews use same AC checklist

**Weekly**:
- Run `/agents context-maintainer` (one person)
- Review and distribute generated refactoring tasks
- Update priorities together

**Conventions**:
- Assign tasks to people
- Use labels for areas (frontend, backend, devops)
- Agree on branching strategy (feature branches, PR workflow)

### For Larger Teams (5+ people)

**Structure**:
- Designate context-maintainer runner (rotating weekly)
- Create epic-level tasks for major features
- Use milestones in backlog.yml
- Regular architectural reviews

**Communication**:
- Document decisions in ADRs (docs/architecture/decisions/)
- Link to task work folders in PRs
- Use backlog labels for team areas
- Run weekly backlog health checks

**Scaling the workflow**:
- Multiple people can run context-gatherer concurrently
- Spec-writer outputs should be reviewed by team lead
- Implementation-planner can parallelize work
- Backlog-manager provides team-wide visibility

---

## Measuring Success

### Healthy Project Indicators

✅ **Good signs**:
- CONTEXT.md updated this month
- CHANGELOG.md has recent entries
- <10% of tasks in "In Progress" state
- Most tasks have work folders
- Agents run regularly (evidence in HANDOFF-*.md files)
- Few or no stale tasks (>2 weeks in progress)

❌ **Warning signs**:
- CONTEXT.md not updated in 3+ months
- CHANGELOG.md not updated
- 50%+ tasks "In Progress"
- No task work folders exist
- Haven't run agents in weeks
- Many tasks marked "Done" with unchecked ACs

### Personal Productivity Metrics

Track these weekly:

- Tasks completed
- Average time to complete task
- Number of blockers encountered
- Documentation completeness (subjective 1-10)
- "Future me" clarity (can you remember what you did?)

**Don't over-optimize for**:
- Speed (quality matters more)
- Number of commits
- Lines of code

**Do optimize for**:
- Completing valuable tasks
- Code quality and test coverage
- Documentation completeness
- Learning and improvement

---

## Continuous Improvement

### Monthly Review Questions

1. **Is the workflow helping or hindering?**
   - What's working well?
   - What's frustrating?
   - What should change?

2. **Is documentation useful?**
   - Can you find what you need?
   - Is it up to date?
   - Is it too much or too little?

3. **Are agents providing value?**
   - Which agents are most useful?
   - Which outputs do you ignore?
   - How can prompts improve?

4. **Are tasks well-sized?**
   - Too big? Break down more
   - Too small? Combine

5. **Is the backlog healthy?**
   - Clear priorities?
   - Dependencies tracked?
   - Reasonable WIP limits?

### Adapting the Framework

**This framework is a starting point, not a religion.**

Feel free to:
- ✅ Adjust task states (add "Blocked", "Review", etc.)
- ✅ Change documentation structure for your needs
- ✅ Skip agents for trivial work
- ✅ Add project-specific conventions
- ✅ Customize templates

Don't:
- ❌ Skip documentation entirely
- ❌ Ignore agent workflow for complex features
- ❌ Let CONTEXT.md go stale for months
- ❌ Stop using backlog task management

---

## Quick Reference

### Daily Commands

```bash
# Morning
/agents backlog-manager "Daily standup"
backlog board

# During work
backlog task edit task-XXX --status "In Progress"
cat backlog/work/task-XXX/spec.md
# ... code, test, update docs ...
git add . && git commit -m "..."

# Evening
/agents backlog-manager "Review progress"
```

### Weekly Commands

```bash
/agents backlog-manager "Weekly review"
/agents context-maintainer
# Review CONTEXT.md
# Update priorities
```

### Before Starting Feature

```bash
/agents context-gatherer  # If needed
/agents spec-writer "Feature Name"
/agents implementation-planner "SPEC-feature.md"
/agents backlog-manager "Create tasks from PLAN-feature.md"
```

### Before Marking Task Done

- [ ] All ACs checked
- [ ] Tests passing
- [ ] CHANGELOG.md updated
- [ ] No new warnings
- [ ] Committed and pushed
- [ ] Task status updated

---

**Remember**: The goal is sustainable, high-quality development. Follow practices that help you ship better code, faster, with less stress.

**When in doubt**: Document it, ask for approval, and iterate.

Happy building! 🚀
