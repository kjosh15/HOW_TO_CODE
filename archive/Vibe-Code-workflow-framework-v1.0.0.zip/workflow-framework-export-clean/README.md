# AI-Assisted Development Workflow Framework

**Version**: 1.0.0
**Status**: Production Ready

## Quick Start

### For New Projects

```bash
# 1. Extract this archive in your project directory
cd your-project
unzip workflow-framework-v1.0.0.zip
cd workflow-framework-export-clean

# 2. Run installer
./install.sh

# 3. Run setup
./setup-workflow-framework.sh "Your Project Name"

# 4. Run onboarding questionnaire
./onboard-project.sh

# 5. Start building!
backlog board
```

### For Existing Projects

```bash
# 1. Extract in your project
cd your-existing-project
unzip workflow-framework-v1.0.0.zip
cd workflow-framework-export-clean

# 2. Run installer
./install.sh

# 3. Run setup
./setup-workflow-framework.sh

# 4. Gather context
# In Claude Code or compatible AI tool:
/agents context-gatherer
```

## What's Included

- **Scripts**:
  - `setup-workflow-framework.sh` - Main setup
  - `onboard-project.sh` - Project questionnaire
  - `github-init.sh` - GitHub integration
  - `export-framework.sh` - Re-export tool
  - `install.sh` - Quick installer

- **Documentation**:
  - `FRAMEWORK-README.md` - Complete guide (start here!)
  - `BEST-PRACTICES.md` - Daily workflows & guidelines
  - `USAGE-GUIDE.md` - Practical examples
  - `EXPORT-INSTRUCTIONS.md` - How to distribute
  - `FRAMEWORK-COMPLETE.md` - Summary & overview

- **Templates**:
  - `templates/WORKFLOW.md` - Agent workflow
  - `templates/AGENTS.md` - Agent reference
  - `templates/CLAUDE.md` - AI instructions (customize!)
  - `templates/BACKLOG.md` - Task management integration

## Requirements

- Git
- One of: npm, bun, or Homebrew (for backlog.md)
- Optional: GitHub CLI (gh)
- Optional: Claude Code or MCP-compatible AI tool

## Documentation

1. **New Users**: Read `FRAMEWORK-README.md`
2. **Daily Usage**: Read `USAGE-GUIDE.md`
3. **Best Practices**: Read `BEST-PRACTICES.md`
4. **Distribution**: Read `EXPORT-INSTRUCTIONS.md`

## The Workflow

```
💡 Idea → 📚 Context → 📝 Spec → 🗺️ Plan → 📋 Tasks → ⚙️ Build → ✅ Done → 📖 Learn
```

### 5 AI Agents Guide You

1. **context-gatherer** - Understand the codebase
2. **spec-writer** - Define requirements (gets your approval!)
3. **implementation-planner** - Create implementation plan
4. **backlog-manager** - Manage tasks & priorities
5. **context-maintainer** - Capture learnings

## Quick Commands

```bash
# Morning
/agents backlog-manager "Daily standup"
backlog board

# Start feature
/agents spec-writer "Feature Name"
/agents implementation-planner "SPEC-feature.md"
/agents backlog-manager "Create tasks from plan"

# Weekly
/agents context-maintainer
```

## Support

- Source: Derived from NTWRKR project
- Backlog.md: https://github.com/MrLesk/Backlog.md
- License: MIT

---

**Happy building!** 🚀
