#!/usr/bin/env bash
set -euo pipefail

################################################################################
# Framework Export Script
#
# This script packages the AI-Assisted Development Workflow Framework
# into a portable bundle that can be installed in any project.
#
# Usage:
#   ./export-framework.sh [output-directory]
#
# Example:
#   ./export-framework.sh ~/Desktop/workflow-framework-bundle
#
################################################################################

VERSION="1.0.0"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m'

log_info() { echo -e "${BLUE}ℹ${NC} $1"; }
log_success() { echo -e "${GREEN}✓${NC} $1"; }
log_warning() { echo -e "${YELLOW}⚠${NC} $1"; }
log_header() {
    echo ""
    echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${MAGENTA}$1${NC}"
    echo -e "${MAGENTA}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
}

################################################################################
# Configuration
################################################################################

# Files to include in the bundle
CORE_FILES=(
    "setup-workflow-framework.sh"
    "onboard-project.sh"
    "github-init.sh"
    "FRAMEWORK-README.md"
    "BEST-PRACTICES.md"
)

TEMPLATE_FILES=(
    "WORKFLOW.md"
    "AGENTS.md"
    "CLAUDE.md"
    "BACKLOG.md"
)

OPTIONAL_FILES=(
    ".gitignore"
)

################################################################################
# Main Export Function
################################################################################

export_framework() {
    local output_dir="${1:-workflow-framework-bundle}"

    log_header "Framework Export Tool v${VERSION}"

    # Create output directory
    log_info "Creating output directory: $output_dir"
    mkdir -p "$output_dir"
    mkdir -p "$output_dir/templates"
    mkdir -p "$output_dir/examples"

    # Copy core files
    log_header "Copying Core Files"
    for file in "${CORE_FILES[@]}"; do
        if [[ -f "$SCRIPT_DIR/$file" ]]; then
            cp "$SCRIPT_DIR/$file" "$output_dir/"
            log_success "Copied: $file"
        else
            log_warning "Not found: $file"
        fi
    done

    # Copy template files
    log_header "Copying Template Files"
    for file in "${TEMPLATE_FILES[@]}"; do
        if [[ -f "$SCRIPT_DIR/templates/$file" ]]; then
            cp "$SCRIPT_DIR/templates/$file" "$output_dir/templates/"
            log_success "Copied template: $file"
        elif [[ -f "$SCRIPT_DIR/$file" ]]; then
            cp "$SCRIPT_DIR/$file" "$output_dir/templates/"
            log_success "Copied template: $file (from root)"
        else
            log_warning "Template not found: $file"
        fi
    done

    # Make scripts executable
    log_header "Setting Permissions"
    chmod +x "$output_dir"/*.sh
    log_success "Made scripts executable"

    # Create README for the bundle
    create_bundle_readme "$output_dir"

    # Create installation script
    create_install_script "$output_dir"

    # Create example task structure
    create_example_task "$output_dir"

    # Create version file
    echo "$VERSION" > "$output_dir/VERSION"

    # Create tarball
    log_header "Creating Archive"
    local bundle_name="workflow-framework-v${VERSION}.tar.gz"
    tar -czf "$bundle_name" -C "$(dirname "$output_dir")" "$(basename "$output_dir")"
    log_success "Created archive: $bundle_name"

    # Summary
    log_header "Export Complete!"
    echo ""
    log_success "Framework exported to: $output_dir"
    log_success "Archive created: $bundle_name"
    echo ""
    echo -e "${CYAN}Distribution Options:${NC}"
    echo "  1. Share the directory: $output_dir"
    echo "  2. Share the archive: $bundle_name"
    echo "  3. Upload to GitHub releases"
    echo "  4. Host on your website"
    echo ""
    echo -e "${CYAN}To install in a new project:${NC}"
    echo "  cd your-project"
    echo "  tar -xzf $bundle_name"
    echo "  ./workflow-framework-bundle/install.sh"
    echo ""
}

################################################################################
# Create Bundle README
################################################################################

create_bundle_readme() {
    local output_dir="$1"

    cat > "$output_dir/README.md" << 'EOF'
# AI-Assisted Development Workflow Framework

**Version**: 1.0.0
**Portable Installation Bundle**

## What is This?

This bundle contains a complete workflow framework for AI-assisted software development. It provides:

- 🤖 **Specialized AI Agents** - Context gathering, spec writing, planning, task management
- 📋 **Task Management** - Backlog.md integration for Git-native task tracking
- 📚 **Documentation System** - Structured documentation that evolves with your project
- 🔄 **Complete Workflow** - From idea to implementation to learning
- 🎯 **Best Practices** - Proven patterns for sustainable development

## Quick Install

```bash
# 1. Extract (if you have the tarball)
tar -xzf workflow-framework-v1.0.tar.gz

# 2. Navigate to your project
cd /path/to/your/project

# 3. Run installer
/path/to/workflow-framework-bundle/install.sh

# 4. Follow the prompts!
```

## What Gets Installed?

- ✅ Backlog.md task management setup
- ✅ Workflow documentation (WORKFLOW.md, AGENTS.md, etc.)
- ✅ AI assistant instructions (CLAUDE.md)
- ✅ Best practices guide
- ✅ Project onboarding questionnaire
- ✅ GitHub integration scripts
- ✅ Template files for tasks and documentation

## Requirements

- Git
- One of: npm, bun, or Homebrew (for backlog.md)
- Optional: GitHub CLI (for GitHub integration)
- Optional: Claude Code or MCP-compatible AI tool

## Documentation

After installation, read:

1. **FRAMEWORK-README.md** - Complete framework overview
2. **BEST-PRACTICES.md** - Development best practices
3. **WORKFLOW.md** - Detailed workflow guide
4. **GETTING-STARTED.md** - Generated after onboarding

## Quick Start After Installation

```bash
# 1. Run project onboarding
./onboard-project.sh

# 2. Review generated spec
cat PROJECT-SPEC.md

# 3. View task board
backlog board

# 4. Start with context gathering
# (In Claude Code or compatible AI tool)
/agents context-gatherer
```

## Support

- **Documentation**: See FRAMEWORK-README.md
- **Best Practices**: See BEST-PRACTICES.md
- **Backlog.md**: https://github.com/MrLesk/Backlog.md
- **Issues**: Check the source repository

## License

MIT License - Free to use, modify, and distribute.

---

**Happy building!** 🚀
EOF

    log_success "Created README.md for bundle"
}

################################################################################
# Create Installation Script
################################################################################

create_install_script() {
    local output_dir="$1"

    cat > "$output_dir/install.sh" << 'INSTALL_SCRIPT'
#!/usr/bin/env bash
set -euo pipefail

# Simple installation script
FRAMEWORK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET_DIR="${1:-.}"

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "AI-Assisted Development Workflow Framework"
echo "Installation"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "Installing to: $TARGET_DIR"
echo ""

# Check if target is valid
if [[ ! -d "$TARGET_DIR" ]]; then
    echo "Error: Target directory does not exist: $TARGET_DIR"
    exit 1
fi

# Copy core files
echo "Copying framework files..."
cp "$FRAMEWORK_DIR/setup-workflow-framework.sh" "$TARGET_DIR/"
cp "$FRAMEWORK_DIR/onboard-project.sh" "$TARGET_DIR/"
cp "$FRAMEWORK_DIR/github-init.sh" "$TARGET_DIR/"
cp "$FRAMEWORK_DIR/FRAMEWORK-README.md" "$TARGET_DIR/"
cp "$FRAMEWORK_DIR/BEST-PRACTICES.md" "$TARGET_DIR/"

# Copy templates
echo "Copying templates..."
cp -r "$FRAMEWORK_DIR/templates" "$TARGET_DIR/"

# Copy examples
if [[ -d "$FRAMEWORK_DIR/examples" ]]; then
    cp -r "$FRAMEWORK_DIR/examples" "$TARGET_DIR/"
fi

# Make scripts executable
chmod +x "$TARGET_DIR"/*.sh

echo ""
echo "✓ Framework installed successfully!"
echo ""
echo "Next steps:"
echo "  1. cd $TARGET_DIR"
echo "  2. ./setup-workflow-framework.sh"
echo "  3. ./onboard-project.sh"
echo ""
INSTALL_SCRIPT

    chmod +x "$output_dir/install.sh"
    log_success "Created install.sh script"
}

################################################################################
# Create Example Task Structure
################################################################################

create_example_task() {
    local output_dir="$1"
    local example_dir="$output_dir/examples/task-example"

    mkdir -p "$example_dir"

    # Example task markdown
    cat > "$example_dir/task-001-example.md" << 'EOF'
---
id: task-001
title: Example Feature Implementation
status: To Do
priority: high
labels: [feature, example]
dependencies: []
created_date: 2025-01-01
---

## Description

This is an example task showing the recommended structure.

**What to build:**
- Component A with functionality X
- API endpoint Y that does Z
- Tests covering edge cases

**Why it matters:**
- Solves user problem P
- Enables feature Q

## Acceptance Criteria

- [ ] AC1: Component A is implemented and tested
- [ ] AC2: API endpoint Y returns expected responses
- [ ] AC3: Tests pass with >80% coverage
- [ ] AC4: Documentation updated

## Dependencies

None for this example task.

## Implementation Notes

*Notes will be added as work progresses*

**Links:**
- Spec: backlog/work/task-001/spec.md
- Implementation: backlog/work/task-001/implementation.md
EOF

    # Example work folder
    mkdir -p "$example_dir/work/task-001"

    cat > "$example_dir/work/task-001/context.md" << 'EOF'
# Task Context: Example Feature Implementation

## Current Understanding

### What Exists
- List relevant existing code
- Related components
- Similar patterns used elsewhere

### What's Missing
- What needs to be built
- What needs to be integrated
- What needs to be tested

## Open Questions

- Question 1?
- Question 2?

## Dependencies

- Dependency A (status)
- Dependency B (status)

## Resources

- Link to relevant docs
- Link to related code
- Link to design docs
EOF

    cat > "$example_dir/work/task-001/spec.md" << 'EOF'
# Specification: Example Feature Implementation

## Objective

Clear statement of what this task accomplishes.

## Requirements

### Functional Requirements
- FR1: System shall do X
- FR2: System shall handle Y
- FR3: System shall validate Z

### Non-Functional Requirements
- NFR1: Performance < 100ms
- NFR2: Error handling comprehensive
- NFR3: Logging for debugging

## API/Interface Design

### Example Endpoint

**POST /api/example**

Request:
```json
{
  "field": "value"
}
```

Response (200 OK):
```json
{
  "result": "success"
}
```

## Testing Strategy

- Unit tests for logic
- Integration tests for API
- Edge case coverage
EOF

    cat > "$example_dir/work/task-001/implementation.md" << 'EOF'
# Implementation Plan: Example Feature

## Status: Not Started

## Approach

High-level approach for implementing this feature.

## Steps

- [ ] Step 1: Setup
- [ ] Step 2: Implement core logic
- [ ] Step 3: Add API endpoint
- [ ] Step 4: Write tests
- [ ] Step 5: Update documentation

## Progress Notes

### 2025-01-01 10:00
Initial planning complete. Ready to start implementation.

## Blockers

None currently.

## Completion Checklist

- [ ] All acceptance criteria met
- [ ] Tests passing
- [ ] Documentation updated
- [ ] CHANGELOG.md updated
- [ ] Code reviewed
EOF

    cat > "$example_dir/work/task-001/decisions.md" << 'EOF'
# Decisions: Example Feature

## Decision Log

### [2025-01-01] Example Decision

**Context**: Needed to choose between approach A and B.

**Options Considered**:
1. Approach A - pros and cons
2. Approach B - pros and cons

**Decision**: Chose approach A

**Rationale**: Reasons for the choice

**Consequences**: What this means going forward
EOF

    log_success "Created example task structure in examples/"
}

################################################################################
# Main
################################################################################

main() {
    local output_dir="${1:-}"

    if [[ -z "$output_dir" ]]; then
        echo "Usage: $0 <output-directory>"
        echo ""
        echo "Example:"
        echo "  $0 ~/Desktop/workflow-framework-bundle"
        echo ""
        echo "Or use default:"
        output_dir="workflow-framework-bundle"
        echo "  Using default: $output_dir"
        echo ""
    fi

    export_framework "$output_dir"
}

main "$@"
